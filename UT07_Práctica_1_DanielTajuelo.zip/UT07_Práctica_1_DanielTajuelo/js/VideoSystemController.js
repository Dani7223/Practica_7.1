import {
    Person, Category, Resource,
    Production, Movie, Serie,
    User, Coordinate
} from "../entities/productions.js"

class VideoSystemController {
    //Campos privados
    #modelVideoSystem;
    #viewVideoSystem;

    #loadVideoSystemObjects() {

        //Creamos un usuario
        let u1 = new User("Dani", "danieltajuelo@gmail.com", "dani2372",);

        //Añadimos los actores y directores

        //Scarface
        let p1 = new Person("Alfredo", "James", "Pacino", "25/4/1940", "alfre.jpg");
        let p2 = new Person("Brian", "Russell", "De Palma", "11/9/1940", "bri.jpg");
        let p7 = new Person("Michelle", "Marie", "Pfeiffer", "29/4/1958", "mich.jpg");

        //Salvar al soldado ryan
        let p3 = new Person("Thomas", "Jeffrey", "Hanks", "9/7/1956", "hank.jpg");
        let p4 = new Person("Steven", "Allan", "Spielberg", "17/2/1965", "spielberg.jpg");
        let p8 = new Person("Mark", "Sinclair", "Vincent", "18/7/1967", "sinc.jpg");

        //Punisher
        let p5 = new Person("Jonathan", "Edward", "Bernthal", "20/9/1976", "ed.jpg");
        let p6 = new Person("Stanley", "Martin", "Lieber", "28/12/1922", "stanlee.jpg");
        let p9 = new Person("Benjamin", "Thomas", "Barnes", "20/8/1981", "barnes.jpg");

        //El padrino
        //P1
        let p11 = new Person("Francis", "Ford", "Coppola", "7/4/1939", "ford.jpg");
        let p12 = new Person("Marlon", "Brando", "Jr", "3/4/1924", "marlo.jpg");

        //American gangster
        let p13 = new Person("Denzel", "Hayes", "Washington", "24/5/1954", "was.jpg");
        let p14 = new Person("Russell", "Ira", "Crowe", "24/12/1964", "ira.jpg");
        let p15 = new Person("Ridley", "Scott", "Rid", "30/11/1937", "rid.jpg");

        //Pulp fiction
        let p16 = new Person("Quentin", "Jerome", "Tarantino", "27/3/1963", "tarantino.jpg");
        let p17 = new Person("John", "Joseph", "Travolta", "18/2/1954", "travol.jpg");
        let p18 = new Person("Samuel", "Leroy", "Jackson", "21/12/1948", "l.jpg");

        //Tyler rake
        let p19 = new Person("Sam", "Hargrave", " ", "26/11/1982", "sam.jpg");
        let p20 = new Person("Christopher", "Hemsworth", " ", "11/8/1983", "hem.jpg");
        let p21 = new Person("David", "Kenneth", "Harbour", "10/4/1975", "dav.jpg");

        //Castillos de arena
        let p22 = new Person("Fernando", "Coimbra", " ", "5/9/1976", "fer.jpg");
        let p23 = new Person("Glen", "Thomas", "Powell", "21/10/1988", "pow.jpg");
        let p24 = new Person("Nicholas", "Caradoc", "Hoult", "7/12/1989", "nico.jpg");

        //Breaking bad
        let p25 = new Person("George", "Vincent", "Gilligan", "10/2/1967", "vin.jpg");
        let p26 = new Person("Bryan", "Lee", "Cranston", "7/3/1956", "ww.jpg");
        let p27 = new Person("Aaron", "Paul", "Sturtevant", "27/8/1979", "jese.jpg");

        //En tierra hostil
        let p28 = new Person("Kathryn", "Ann", "Bigelow", "27/11/1951", "kat.jpg");
        let p29 = new Person("Jeremy", "Lee", "Renner", "7/1/1971", "lee.jpg");
        let p30 = new Person("Anthony", "Dwane", "Mackie", "23/9/1978", "dawne.jpg");

        //John wick
        let p31 = new Person("Chad", "Stahelski", " ", "20/9/1966", "chad.jpg");
        let p32 = new Person("Keanu", "Charles", "Reeves", "2/9/1964", "reeve.jpg");
        let p33 = new Person("Laurence", "John", "Fishburne", "30/7/1961", "fish.jpg");

        //El único superviviente
        let p34 = new Person("Peter", "Berg", " ", "11/3/1964", "peter.jpg");
        let p35 = new Person("Marky", "Wahlberg", " ", "5/7/1971", "marky.jpg");
        let p36 = new Person("Taylor", "Kitsch", " ", "30/7/1961", "tay.jpg");



        //Añadimos las categorias
        let c1 = new Category("Mafia", "Las películas de mafia, una versión de las películas de gánsteres, son un subgénero de las películas de crimen");
        let c2 = new Category("Cine belico", "El cine bélico es el género cinematográfico al que pertenecen las películas y series de televisión cuyo argumento se centra en las guerras");
        let c3 = new Category("Accion", "El llamado cine de acción es un género cinematográfico donde prima la espectacularidad de las imágenes por medio de efectos especiales");

        //Añadimos objetos resources
        let r1 = new Resource("2h 50min", "https://www.peliculas/scarface.com");
        let r2 = new Resource("2h 49min", "https://www.peliculas/salvarsoldadoryan.com")
        let r3 = new Resource("23 h", "https://www.series/punisher.com");
        let r4 = new Resource("15 h", "https://www.series/punisher2.com");
        let r5 = new Resource("13 h", "https://www.series/breaking1.com");
        let r6;
        let r7;
        let r8;
        let r9;
        let r10 = new Resource("2h 55m", "https://www.peliculas/padrino.com");
        let r11 = new Resource("2h 56m", "https://www.peliculas/americang.com");
        let r12 = new Resource("2h 34m", "https://www.peliculas/pulp.com");
        let r13 = new Resource("1h 56m", "https://www.peliculas/tyler.com");
        let r14 = new Resource("1h 53m", "https://www.peliculas/castillos.com");
        let r15 = new Resource("2h 11m", "https://www.peliculas/hostil.com");
        let r16 = new Resource("2h 11m", "https://www.peliculas/wick3.com");
        let r17 = new Resource("2h 1m", "https://www.peliculas/lonesurvivor.com");


        //Creamos unas cuantas coordenadas que nos servirán para más tarde
        let co1 = new Coordinate(25.77427, -80.19366);
        let co2 = new Coordinate(49.12, -0.43);
        let co3 = new Coordinate(52.52, 13.41);
        let co4 = new Coordinate(40.71427, -74.00597);
        let co5 = new Coordinate(14.8971921, 100.83273);
        let co6 = new Coordinate(34.0536909, -118.242766);
        let co7 = new Coordinate(22.3511148, 78.6677428);
        let co8 = new Coordinate(24.4769288, 90.2934413);
        let co9 = new Coordinate(33.0955793, 44.1749775);
        let co10 = new Coordinate(34.5708167, -105.993007);
        let co11 = new Coordinate(49.7171716, 18.8038594);
        let co12 = new Coordinate(33.7680065, 66.2385139);

        //Creamos las producciones
        let m1 = new Movie("Scarface", "Estados Unidos", "1983", "Antonio «Tony» Montana es un expresidiario cubano que llega a los Estados Unidos durante el éxodo de Mariel en mayo de 1980. Junto a su mejor amigo, Manolo «Manny» Ribera, son recluidos en Cayo Hueso con el resto de los demás refugiados cubanos a la espera de una resolución política", "scarface.jpg", [co1], r1);
        let m2 = new Movie("Salvar al Soldado Ryan", "Alemania", "1998", "Tras el desembarco de Normandía, unos soldados americanos deben arriesgar sus vidas para salvar al soldado James Ryan, cuyos tres hermanos han muerto en la guerra.", "soldado.jpg", [co2, co3], r2);
        let s2 = new Serie("The Punisher", "Estados Unidos", "2017", "Un antiguo marine decidido a castigar a los asesinos de su familia termina atrapado en una conspiración militar. Jon Bernthal protagoniza esta saga de furia y venganza basada en el cómic de Marvel.", "punisher.jpg", [r3, r4], [co4], 2);
        let m3 = new Movie("El padrino", "Estados Unidos", "1972", "Don Vito Corleone es el respetado y temido jefe de una de las cinco familias de la mafia de Nueva York en los años 40. El hombre tiene cuatro hijos: Connie, Sonny, Fredo y Michael, que no quiere saber nada de los negocios sucios de su padre.", "padrino.jpg", [co1], r10);
        let m4 = new Movie("American Gangster", "Estados Unidos", "2007", "Frank Lucas, tras la muerte de su jefe, aprovecha la oportunidad para construir su imperio del narcotráfico. Por su parte, Richie Roberts es un policía incorruptible que persigue a los clanes. La férrea ética de ambos les enfrentará inevitablemente.", "american.jpg", [co1, co5], r11);
        let m5 = new Movie("Pulp Fiction", "Estados Unidos", "1994", "Historias de dos matones, un boxeador y una pareja de atracadores de poca monta envueltos en una violencia espectacular e irónica", "pulp.jpg", [co6], r12);
        let m6 = new Movie("Tyler Rake", "Bangladesh", "2020", "Tyler Rake, un intrépido mercenario, es enviado a Bangladesh por un poderoso mafioso encarcelado para que salve a su hijo secuestrado.", "tyler.jpg", [co5, co7, co8], r13);
        let m7 = new Movie("Castillo de arena", "Irak", "2017", "Tras la invasión de Irak en 2003, un pelotón trata de reparar el sistema de abastecimiento de agua en una zona hostil.", "castillo.jpg", [co9], r14);
        let s3 = new Serie("Breaking Bad", "Estados Unidos", "2008", "La serie narra las historias de Walter White, un profesor de química que después de ser diagnosticado de un cáncer pulmonar inoperable termina vendiendo metanfetamina, y de Jesse Pinkman, su exalumno.", "breaking.jpg", [r5 = new Resource("13 h", "https://www.series/breaking1.com"), r6 = new Resource("13 h", "https://www.series/breaking2.com"), r7 = new Resource("13 h", "https://www.series/breaking3.com"), r8 = new Resource("13 h", "https://www.series/breaking4.com"), r9 = new Resource("15 h", "https://www.series/breaking5.com")], [co10], 5);
        let m8 = new Movie("En tierra hostil", "Irak", "2010", "Los integrantes de un comando especializado en desactivación de explosivos durante la guerra de Irak, deben hacer frente a situaciones extremas que pondrán a prueba muchas de sus facultades.", "hostil.jpg", [co9], r15);
        let m9 = new Movie("John Wick 3: Parabellum", "Estados Unidos", "2014", "En Nueva York, John Wick, un asesino a sueldo retirado, vuelve otra vez a la acción para vengarse de los gánsteres que le quitaron todo..", "john.jpg", [co11], r16);
        let m10 = new Movie("El unico superviviente", "Afganistan", "2014", "A un equipo de élite de las fuerzas especiales del ejército norteamericano le encargan una peligrosa misión, la operación Red Wing. Su objetivo es capturar o matar a un líder terrorista talibán, Admad Shad, que se esconde en una zona boscosa de Afganistán.", "unico.jpg", [co12], r17);


        //Añadimos las categorias al sistema
        this.#modelVideoSystem.addCategory(c3)
        this.#modelVideoSystem.addCategory(c1)
        this.#modelVideoSystem.addCategory(c2)



        //Añadimos todas las producciones de una a la categoria de acción
        this.#modelVideoSystem.assignCategory(c3, [m9, s2, m6, s3])

        //Añadimos todas las producciones de una a la categoria de mafia
        this.#modelVideoSystem.assignCategory(c1, [m1, m3, m4, m5])


        //Añadimos todas las producciones de una a la categoria de cine belico
        this.#modelVideoSystem.assignCategory(c2, [m2, m7, m8, m10])


        //Asignamos cada director a su pelicula
        this.#modelVideoSystem.assignDirector(p2, m1)
        this.#modelVideoSystem.assignDirector(p4, m2)
        this.#modelVideoSystem.assignDirector(p6, s2)
        this.#modelVideoSystem.assignDirector(p11, m3)
        this.#modelVideoSystem.assignDirector(p15, m4)
        this.#modelVideoSystem.assignDirector(p16, m5)
        this.#modelVideoSystem.assignDirector(p19, m6)
        this.#modelVideoSystem.assignDirector(p22, m7)
        this.#modelVideoSystem.assignDirector(p25, s3)
        this.#modelVideoSystem.assignDirector(p28, m8)
        this.#modelVideoSystem.assignDirector(p31, m9)
        this.#modelVideoSystem.assignDirector(p34, m10)

        //Añadimos los actores
        this.#modelVideoSystem.addActors([p7, p1, p3, p8, p5, p9, p12, p13, p14, p17
            , p18, p20, p21
            , p23, p24, p26, p27, p29, p30, p32, p33, p35, p36
        ])

        //Añadimos todos los actores a sus respectivas producciones

        //Scarface
        this.#modelVideoSystem.assignActors([p7, p1], m1)

        //Soldado ryan
        this.#modelVideoSystem.assignActors([p3, p8], m2)

        //Punisher
        this.#modelVideoSystem.assignActors([p5, p9], s2)

        //El padrino
        this.#modelVideoSystem.assignActors([p1, p12], m3)

        //American gangster
        this.#modelVideoSystem.assignActors([p13, p14], m4)

        //Pulp fiction
        this.#modelVideoSystem.assignActors([p17, p18], m5)

        //Tyler Rake
        this.#modelVideoSystem.assignActors([p21, p20], m6)

        //Castillo de arena
        this.#modelVideoSystem.assignActors([p23, p24], m7)

        //Breaking Bad
        this.#modelVideoSystem.assignActors([p26, p27], s3)

        //En tierra hostil
        this.#modelVideoSystem.assignActors([p29, p30], m8)

        //John Wick
        this.#modelVideoSystem.assignActors([p32, p33], m9)

        //El único superviviente
        this.#modelVideoSystem.assignActors([p35, p36], m10)
    }

    constructor(modelVideoSystem, viewVideoSystem) {
        this.#modelVideoSystem = modelVideoSystem;
        this.#viewVideoSystem = viewVideoSystem;

        // Eventos iniciales del Controlador
        this.onLoad();
        this.onInit();


        this.#viewVideoSystem.bindInit(this.handleInit);

        // this.#viewVideoSystem.bindShowMovies(this.handleShowMovies);


    }

    //Función que se ejecutará nada mas empezar
    onInit = () => {

        //Generamos 3 numeros aleatorios que serán las posiciones de las producciones para el carrousel
        let n = this.#modelVideoSystem.randomNumber();

        //Iniciamos la pagina y le pasamos las producciones aleatorias
        this.#viewVideoSystem.init(this.#modelVideoSystem.getProductionP(n));

        //Llamamos al bind para mostrar las producciones de una categoria
        //pasandole el handle para mostrarla
        this.#viewVideoSystem.bindShowMovies(this.handleShowMovies);

        //Llamamos al bind para mostrar el carrousel
        //pasandole el handle para mostrarlo
        this.#viewVideoSystem.bindCarousel(this.handleSingleMovie);
    }


    //Manejador del init
    handleInit = () => {
        this.onInit();

    }

    //Función para cargar los objetos y los métodos para
    // las categorias directores actores y producciones
    onLoad = () => {
        this.#loadVideoSystemObjects();
        this.onAddCategory();
        this.onAddDirector();
        this.onAddActors();
        this.onAddMovie();
        this.onCloseWindow();
    }


    //Función para mostrar las categorias en la barra de navegación y para que nos lleve a las
    //producciones de esa categoria al pinchar
    onAddCategory = () => {

        //Nos muestra las categorias en la barra
        this.#viewVideoSystem.showCategoriesNavbar(this.#modelVideoSystem.categories);

        //Nos lleva a las producciones de esa categoria al pinchar en una
        this.#viewVideoSystem.bindProductsCategoryNavbar(
            this.handleProductsCategoryList
        );


    }

    //Función para mostrar los directores en la barra de navegación y para que nos lleve a la
    //carta individual al pinchar
    onAddDirector = () => {
        //Nos muestra los directores en la barra
        this.#viewVideoSystem.showDirectorsNavbar(this.#modelVideoSystem.directors);

        //Nos lleva a la tarjeta individual del director en el que pinchemos
        this.#viewVideoSystem.bindProductsDirectorsNavbar(
            this.handleProductsDirectors
        );

    }

    //Función para mostrar una pelicula individual
    onAddMovie = () => {
        this.#viewVideoSystem.bindSingleMovie();
    }


    //Función para mostrar los actores en la barra de navegación y para que nos lleve a la
    //carta individual al pinchar
    onAddActors = () => {
        //Nos muestra los actores en la barra
        this.#viewVideoSystem.showActorsNavbar(this.#modelVideoSystem.actors);

        //Nos lleva a la tarjeta individual del actor en el que pinchemos
        this.#viewVideoSystem.bindSingleActor(
            this.handleSingleActor
        );

    }

    onCloseWindow = () => {
        
        this.#viewVideoSystem.showCloseWindows();

        this.#viewVideoSystem.bindCloseWindow(this.handleDeleteWindows);
    }

    //El manejador que nos mostrará la carta individual del director que pinchemos
    handleProductsDirectors = (director) => {
        this.handleSingleDirector(director);
    }

    //El manejador que nos mostrará la producción individual del director que pinchemos
    handleProductsCategoryList = (type) => {
        this.handleShowMovies(type);
    }


    //Manejador que nos muestra todas las peliculas de una categoria
    handleShowMovies = (type) => {

        let title = "";

        //Llamamos al método getCategory del model
        let category = this.#modelVideoSystem.getCategory(type);

        //Creamos un iterador para las producciones
        const iterator = category.products[Symbol.iterator]();

        //Según el tipo que se nos pase le daremos
        //un titulo u otro a la categoria
        if (type === "Accion") {
            title = "Accion";
        } else if ((type === "Mafia")) {
            title = "Mafia";
        } else if (type === "Cine belico") {
            title = "Cine belico";
        }

        //Llamamos al metodo de la vista que nos muestra las peliculas
        this.#viewVideoSystem.showMovies(iterator, title);

        //Llamamos al bind para que al pinchar luego en alguna pelicula en concreto
        //nos muestre la tarjeta indivual
        this.#viewVideoSystem.bindSingleMovie(this.handleSingleMovie);

    }

    //Manejador que nos muestra la pelicula individual en la que pinchemos
    handleSingleMovie = (movie) => {

        //Consegimos la producción con el nombre de la pelicula que se nos pasa
        let m = this.#modelVideoSystem.getProduction((movie))

        let d;

        //Guardamos en una variable el director de esa produccion
        for (const dir of this.#modelVideoSystem.getDirs((m))) {
            d = dir;
        }

        let a = [];

        //Guardamos en un array los actores de esas producciones
        for (const act of this.#modelVideoSystem.getCast((m))) {
            a.push(act);
        }


        //Llamamos a la función para mostrar una pelicula individual
        //pasandole la produccion, el director y los actores
        this.#viewVideoSystem.showSingleMovie(m, d, a);

        //Llamamos a los bind que se ejecutarán al pinchar sobre el director
        //que nos llevará a su tarjeta individual
        this.#viewVideoSystem.bindDirectorMovie(
            this.handleSingleDirector
        );

        //Llamamos a los bind que se ejecutarán al pinchar sobre cualquier actor
        //que nos llevará a su tarjeta individual
        this.#viewVideoSystem.bindActorMovie(
            this.handleSingleActor
        );

        //Llamamos a los bind que se ejecutarán al pinchar sobre cualquier actor
        //que nos llevará a su tarjeta individual
        this.#viewVideoSystem.bindNewWindow(
            this.handleNewWindow
        );
    }

    //Manejador que nos muestra el director individualmente
    handleSingleDirector = (director) => {

        //Conseguimos el objeto director con el nombre que conseguimos del bind
        let dir = this.#modelVideoSystem.getDirector(director);

        let ms = [];

        //Guardamos en un array las producciones que tiene ese director
        for (const act of dir.products) {
            ms.push(act);
        }

        //Llamamos a la función para mostrar la carta individual del director
        this.#viewVideoSystem.showSingleDirector(dir, ms);


        //Iniciamos el bind para que en caso de que en la tarjeta individual del director
        //pinchemos en una producción en la que ha participado nos lleve a esa producción
        this.#viewVideoSystem.bindMovieCast(
            this.handleSingleMovie
        );
    }

    //Manejador que nos muestra el actor individualmente
    handleSingleActor = (actor) => {

        //Conseguimos el objeto actor con el nombre que conseguimos del bind
        let act = this.#modelVideoSystem.getActor(actor);


        let ms = [];

        //Guardamos en un array todas sus produccioens
        for (const acts of act.products) {
            ms.push(acts);
        }

        //Llamamos a la función para mostrar la carta individual del actor
        this.#viewVideoSystem.showSingleActor(act, ms);

        //Iniciamos el bind para que en caso de que en la tarjeta individual del actor
        //pinchemos en una producción en la que ha participado nos lleve a esa producción
        this.#viewVideoSystem.bindMovieCast(
            this.handleSingleMovie
        );
    }


    //Manejador que nos muestra el actor individualmente
    handleNewWindow = (movie) => {


        //Consegimos la producción con el nombre de la pelicula que se nos pasa
        let m = this.#modelVideoSystem.getProduction((movie))

        //Abrimos una nueva ventana con la información de la pelicula que tenemos
        this.#viewVideoSystem.showNewWindowProduction(m);

        //Añadimos la ventana por un método en el model
        //para asi poder llevar las referencias de las ventanas abiertas
        //para poder luego poder cerrarlas todas
        this.#modelVideoSystem.addWindow(m)


    }



    //Manejador que nos cierra todas las ventanas
    handleDeleteWindows = () => {

        //Método que cierra todas las ventanas
        this.#modelVideoSystem.closeWindows();

    }

}

export default VideoSystemController;
