import {
    Person, Category, Resource,
    Production, Movie, Serie,
    User, Coordinate
} from "../entities/productions.js"


class BaseException extends Error {
    constructor(message = "", fileName, lineNumber) {
        super(message, fileName, lineNumber);
        this.name = "BaseException";
        if (Error.captureStackTrace) {
            Error.captureStackTrace(this, BaseException);
        }
    }
}


class AbstractClassException extends BaseException {
    constructor(fileName, lineNumber) {
        super("Esta clase es abstracta!!", fileName, lineNumber);
        this.name = "AbstractClassException";
    }
}


class EmptyValueException extends BaseException {
    constructor(fileName, lineNumber) {
        super("El valor esta vacio!", fileName, lineNumber);
        this.name = "EmptyValueException";
    }
}


class ExistedElementException extends BaseException {
    constructor(fileName, lineNumber) {
        super("Este elemento ya existe!", fileName, lineNumber);
        this.name = "ExistedElementException";
    }
}

class NotExistedElementException extends BaseException {
    constructor(fileName, lineNumber) {
        super("Este elemento no existe!", fileName, lineNumber);
        this.name = "NotExistedElementException";
    }
}


class InvalidTypeException extends BaseException {
    constructor(fileName, lineNumber) {
        super("Tipo invalido para este objeto!", fileName, lineNumber);
        this.name = "InvalidTypeException";
    }
}

class InvalidLatitudeException extends BaseException {
    constructor(fileName, lineNumber) {
        super("La latitud introducida no es correcta", fileName, lineNumber);
        this.name = "InvalidLatitudeException";
    }
}


class InvalidLongitudeException extends BaseException {
    constructor(fileName, lineNumber) {
        super("La longitud introducida no es correcta", fileName, lineNumber);
        this.name = "InvalidLongitudeException";
    }
}


class InvalidEmailException extends BaseException {
    constructor(fileName, lineNumber) {
        super("La longitud introducida no es correcta", fileName, lineNumber);
        this.name = "InvalidEmailException";
    }
}

//Declaramos una variable a un patron IIFE
let VideoSystem = (function () {

    //Declaramos una variable para que luego nos diga si esta instanciado el objeto
    let instatiated;

    function init(name) { //Inicialización del Singleton

        //Creamos la clase VideoSystem
        class VideoSystem {

            //Declaramos la propiedad nombre del videosystem y todos los arrrays para guardar objetos
            #name;
            #categories = [];
            #users = [];
            #productions = [];
            #actors = [];
            #directors = [];
            #windows = [];

            //Creamos el constructor de la clase VideoSystem con solo el nombre
            constructor(name) {
                this.#name = name;

                //Controlamos que el nombre no esté vacio
                if (this.#name = "") throw new EmptyValueException();
            }

            //Getters de VideoSystem
            get name() {
                return this.#name;
            }

            //Getters de VideoSystem
            get windows() {
                return this.#windows;
            }

            //Setters de VideoSystem
            set name(value) {
                this.#name = value;
            }


            get productions() {
                return this.#productions;
            }


            //Método para cerrar todas las ventanas de golpe
            closeWindows() {

                //Inicializamos la variable win
                //y declaramos ws dandole como valor el array interno de 
                //todas las ventanas
                let win;
                let ws = this.#windows;

                //Recorremos con un for el array interno de las ventanas
                for (let i = 0; i < ws.length; i++) {
                    //Por cada elemento hacemos un window open, con el titulo
                    //de la producción en la posición de i
                    win = window.open('production.html', ws[i].title);
                    //y cerramos la ventana
                    win.close();
                }


            }


            //Método para añadir usuarios
            addWindow(pro) {

                //Comprobamos que el parámetro que se pasa es instacia de Production, ya sea movie o serie
                if (!(pro instanceof Production)) throw new InvalidTypeException();

                //Guardamos en una variable un array que declaramos
                //para llevar constancia de las ventanas que se van abriendo
                let ws = this.#windows;

                //metemos en ese array interno la producción que le pasamos
                ws.push(pro);

            }


            //Dado una categoría, devuelve la posición de esa categoría en el array de categorías o -1 si no lo encontramos.
            //Hemos elegido comparar por contenido no por referencia.
            #getCategoryPosition(elem) {
                if (!(elem instanceof Category)) throw new InvalidTypeException();

                function compareElements(element) {
                    return (element.category.name === elem.name)
                }

                return this.#categories.findIndex(compareElements);
            }



            //Dado un director, devuelve la posición de ese director en el array de directores o -1 si no lo encontramos.
            //Hemos elegido comparar por contenido no por referencia.
            #getDirectorPosition(elem) {
                if (!(elem instanceof Person)) throw new InvalidTypeException();

                function compareElements(element) {
                    return (element.director.name === elem.name)
                }

                return this.#directors.findIndex(compareElements);
            }


            //Dado una actor, devuelve la posición de ese actor en el array de actors o -1 si no lo encontramos.
            //Hemos elegido comparar por contenido no por referencia.
            #getActorPosition(ac) {

                if (!(ac instanceof Person)) throw new InvalidTypeException();

                function compareElements(element) {
                    return (element.actor.name === ac.name)
                }

                return this.#actors.findIndex(compareElements);
            }



            //Dado una production, devuelve la posición de esa production en el array da productions o -1 si no lo encontramos.
            //Hemos elegido comparar por contenido no por referencia.
            #getProductionPosition(product, pro = this.#productions) {
                // console.log("product instanceof Production")
                // if (!(product instanceof Production)) throw new InvalidTypeException();

                function compareElements(element) {
                    return (element.title === product.title)
                }

                return pro.findIndex(compareElements);
            }

            //Dado una production, devuelve la posición de esa production en el array da productions o -1 si no lo encontramos.
            //Hemos elegido comparar por contenido no por referencia.
            getProduction(ti) {

                let position;

                for (let i = 0; i < this.#productions.length; i++) {
                    if (this.#productions[i].title === ti) position = i;

                }

                return (this.#productions[position]);
            }


            //Dado una production, devuelve la posición de esa production en el array da productions o -1 si no lo encontramos.
            //Hemos elegido comparar por contenido no por referencia.
            getProductionP(numbers) {

                let pr = [];

                for (let i = 0; i < numbers.length; i++) {
                    pr.push(this.#productions[numbers[i]]);

                    //  console.log(this.#productions[numbers[i]])

                }

                return pr;
            }



            //Método para añadir una categoria, donde ademas de añadir la categoria, añadiremos un array de producciones
            //para luego asignar esas categorias a produciones, todo ello en un objeto
            addCategory(element) {

                //Comprobamos que element sea una Category y que no sea null
                if ((!(element instanceof Category)) || (element == null)) throw new InvalidTypeException();

                //Conseguimos la posición de la categoria que le pasamos
                let position = this.#getCategoryPosition(element);
                if (position === -1) {
                    // Añade objeto literal con una propiedad para la categoría y un array para las producciones dentro de la categoría
                    this.#categories.push(
                        {
                            category: element,
                            products: []
                        }
                    );

                    return this.#categories;

                } else {
                    throw new ExistedElementException();
                }
            }

            //Método para eliminar categorias
            removeCategory(element) {

                //Comprobamos la instancia 
                if ((!(element instanceof Category)) || (element == null)) throw new InvalidTypeException();

                // Obtenemos la posición de la categoría
                let categoryP = this.#getCategoryPosition(element);
                //Si existe
                if (categoryP !== -1) {
                    //Borramos la categoria
                    this.#categories.splice(categoryP, 1);
                    return this.#categories.length;

                } else {
                    //Salta excepción
                    throw new NotExistedElementException();
                }

            }




            //Método para añadir usuarios
            addUser(element) {

                //Si el usuario ya existia(Comprobamos con findIndex) mostramos una excepción personalizada
                if ((this.#users.findIndex((user) => user.username === element.username) !== -1)) throw new ExistedElementException;

                //Si el usuario ya existia(Comprobamos con findIndex) mostramos una excepción personalizada
                if ((this.#users.findIndex((user) => user.email === element.email) !== -1)) throw new ExistedElementException;

                //Comprobamos que el elemento sea un usuario y no sea null
                if ((element == null) || (!(element instanceof User))) throw new InvalidTypeException();

                //En caso de que no exista, añadimos al array ese elemento
                this.#users.push(element);

                //Y con este return devolvemos la longitud de la lista de usuarios después de añadir
                return this.#users.length;
            }

            //Método para eliminar usuarios
            removeUser(element) {

                //Comprobamos las instancias de element
                if ((element == null) || (!(element instanceof User))) throw new InvalidTypeException();

                //Declaramos una variable y le damos un valor, que es el indice de dicho usuario
                if ((this.#users.findIndex((user) => user.username === element.username) === -1)) throw new NotExistedElementException;

                //Guardamos en una variable el indice del usuario porque existe
                let i = this.#users.findIndex((user) => user.username === element.username);

                //Borramos el usuario que hemos recuperado en el find index arriba en la variable i
                this.#users.splice(i, 1)

                //Y con este return devolvemos la longitud de la lista usuarios después de borrar
                return this.#users.length;

            }




            //Método para añadir producciones
            addProduction(element) {

                //Comprobamos instancias
                if ((element == null) || (!(element instanceof Production))) throw new InvalidTypeException();

                //Si la producción ya existia(Comprobamos con findIndex) mostramos una excepción personalizada
                if ((this.#productions.findIndex((production) => production.title === element.title) !== -1)) throw new ExistedElementException();

                //En caso de que no exista, añadimos al array ese elemento
                this.#productions.push(element);

                //Y con este return devolvemos la longitud de la lista una vez añadida la producción
                return this.#productions.length;
            }

            //Método para eliminar producciones
            removeProduction(element) {

                //Comprobamos instancia de element
                if ((element == null) || (!(element instanceof Production))) throw new InvalidTypeException();

                //Declaramos una variable y le damos un valor, que es el indice 
                if ((this.#productions.findIndex((production) => production.name === element.name) === -1)) throw new NotExistedElementException();

                //Guardamos en una variable el indice de la producción porque existe
                let i = this.#productions.findIndex((production) => production.name === element.name);

                //Borramos la producción que hemos recuperado en el find index arriba en la variable i
                this.#productions.splice(i, 1)

                //Y con este return devolvemos la longitud de la lista una vez borrado la producción
                return this.#productions.length;

            }




            //Método para añadir actores
            addActors(elements) {

                for (let i = 0; i < elements.length; i++) {
                    //Conseguimos la posición del actor que le pasamos
                    let position = this.#getActorPosition(elements[i]);
                    //Si no existe
                    if (position === -1) {
                        // Añade objeto literal con una propiedad para el actor y un array para las producciones del actor
                        this.#actors.push(
                            {
                                actor: elements[i],
                                products: []
                            }
                        );

                        //Si no existe salta una excepción de que ese elemento ya existe
                    } else {
                        throw new ExistedElementException();
                    }
                }

            }

            //Método para eliminar actores
            removeActor(element) {
                //Comprobamos instancias
                if ((!(element instanceof Person)) || (element == null)) throw new InvalidTypeException();

                // Obtenemos la posición del actor
                let actorP = this.#getActorPosition(element);
                //Si existe
                if (actorP !== -1) {
                    //Borramos el usuario
                    this.#actors.splice(actorP, 1);
                    return this.#actors.length;

                    //Si no mostramos excepción
                } else {
                    throw new NotExistedElementException();
                }

            }



            //Método para añadir directores
            addDirector(element) {

                //Comprobamos instancias
                if ((!(element instanceof Person)) || (element == null)) throw new InvalidTypeException();

                //Conseguimos la posición de ese director
                let position = this.#getDirectorPosition(element);
                //Si no existe
                if (position === -1) {
                    // Añade objeto literal con una propiedad para el director y un array para las producciones dentro del director
                    this.#directors.push(
                        {
                            director: element,
                            products: []
                        }
                    );

                    //En caso de que exista ya, salta una excepción
                } else {
                    throw new ExistedElementException();
                }
            }

            //Método para eliminar directores
            removeDirector(element) {

                //Comprobamos instancias
                if ((!(element instanceof Person)) || (element == null)) throw new InvalidTypeException();

                // Obtenemos la posición del director
                let directorP = this.#getDirectorPosition(element);
                //Si existe el director 
                if (directorP !== -1) {
                    //Borramos el director y retornamos la longitud de la lista
                    this.#directors.splice(directorP, 1);
                    return this.#directors.length;

                    //Si no existe lo mostramos con un error
                } else {
                    throw new NotExistedElementException();


                }
            }


            // //Retornamos el objeto iterador para recuperar las categorias
            get categories() {

                //Declaramos una variable y le damos como valor el array de categorias, guardando también su referencia
                let list = this.#categories;

                return {
                    *[Symbol.iterator]() {
                        //Con este for of recorremos todos los elementos y los devolvemos uno por uno con el yield
                        for (let category of list) {
                            yield category;
                        }
                    }
                }
            }




            // //Retornamos el objeto iterador para recuperar los usuarios
            get users() {

                //Declaramos una variable y le damos como valor el array de usuarios, guardando también su referencia
                let list = this.#users;

                return {
                    *[Symbol.iterator]() {
                        //Con este for of recorremos todos los elementos y los devolvemos uno por uno con el yield
                        for (let user of list) {
                            yield user;
                        }
                    }
                }
            }



            // //Retornamos el objeto iterador para recuperar las producciones
            get productions() {

                //Declaramos una variable y le damos como valor el array de producciones, guardando también su referencia
                let list = this.#productions;

                return {
                    *[Symbol.iterator]() {
                        //Con este for of recorremos todos los elementos y los devolvemos uno por uno con el yield
                        for (let production of list) {
                            yield production;
                        }
                    }
                }
            }



            //Retornamos el objeto iterador para recuperar los actores
            get actors() {

                //Declaramos una variable y le damos como valor el array de actores, guardando también su referencia
                let list = this.#actors;

                return {
                    *[Symbol.iterator]() {
                        //Con este for of recorremos todos los elementos y los devolvemos uno por uno con el yield
                        for (let actor of list) {
                            yield actor;
                        }
                    }
                }
            }


            // //Retornamos el objeto iterador para recuperar los directores
            get directors() {

                //Declaramos una variable y le damos como valor el array de directores, guardando también su referencia
                let list = this.#directors;

                return {
                    *[Symbol.iterator]() {
                        //Con este for of recorremos todos los elementos y los devolvemos uno por uno con el yield
                        for (let actor of list) {
                            yield actor;
                        }
                    }
                }
            }

            //Función para asignar categoria al VideoSystem
            assignCategory(category, production) {

                //Comprobamos que los objetos que le pasamos sean instancias de Category y Production respectivamente
                if (!(category instanceof Category)) throw new InvalidTypeException();

                //Guardamos en una varible la lista de producciones
                let pro = this.#productions;

                // if (!(element instanceof Production)) throw new InvalidTypeException();

                for (let i = 0; i < production.length; i++) {


                    let productionP = this.#getProductionPosition(production[i], pro);

                    if (productionP === -1) {
                        this.addProduction(production[i]);
                        productionP = this.#productions.length - 1

                    }

                    //Obtenemos las posiciones tanto de las categorias como de las production en sus arrays
                    let categoryP = this.#getCategoryPosition(category);


                    //Si la posición es -1 es que no existe, por lo que tenemos que añadir con un add
                    // y le damos a la position el último valor ya que hemos añadido ese valor y será el último
                    //en la lista
                    if (categoryP === -1) {
                        this.addCategory(category);
                        categoryP = this.#categories.length - 1

                    }

                    //comprueba si la production ya está asignada a la categoría, si no está asignada la asigna
                    if (this.#getProductionPosition(production, this.#categories[categoryP].products) === -1) {
                        this.#categories[categoryP].products.push(this.#productions[productionP]);
                    }


                }

            }


            //Función para deasignar una categoria del VideoSystem
            deassignCategory(category, production) {


                //Comprobamos las instancias de los parámetros
                if (!(category instanceof Category)) throw new InvalidTypeException();

                if (!(production instanceof Production)) throw new InvalidTypeException();

                //Obtenemos las posiciones tanto de las categorias como de las production en sus arrays
                let categoryP = this.#getCategoryPosition(category);

                //Guardamos en una varible la lista interna de producciones, en la posición de la categoria que le hemos pasado
                let pro = this.#categories[categoryP].products;

                let productionP = this.#getProductionPosition(production, pro);


                //Si la categoria existe en el array
                if (categoryP !== -1) {
                    //Comprobamos que la producción también exista
                    if (productionP !== -1) {
                        //Y en ese caso lo deasignamos
                        this.#categories[categoryP].products.splice(productionP, 1);

                    } else {
                        //Lanzamos una excepción si la producción no existe
                        throw NotExistedElementException();
                    }

                } else {
                    //Lanzamos una excepción si la categoria no existe
                    throw NotExistedElementException();
                }

                //Retornamos la longitud de la lista interna de products
                return this.#categories[categoryP].products.length;

            }



            //Función para asignar director al VideoSystem
            assignDirector(director, production) {

                //Comprobamos que los objetos que le pasamos sean instancias de Person y Production respectivamente
                if (!(director instanceof Person)) throw new InvalidTypeException();

                if (!(production instanceof Production)) throw new InvalidTypeException();

                //Guardamos en una varible la lista de producciones
                let pro = this.#productions;

                //Obtenemos las posiciones tanto del director como de las production en sus arrays
                let directorP = this.#getDirectorPosition(director);


                let productionP = this.#getProductionPosition(production, pro);


                //Si la posición es -1 es que no existe, por lo que tenemos que añadir con un add
                // y le damos a la position el último valor ya que hemos añadido ese valor y será el último
                //en la lista
                if (directorP === -1) {
                    this.addDirector(director);
                    directorP = this.#directors.length - 1

                }

                if (productionP === -1) {
                    this.addProduction(production);
                    productionP = this.#productions.length - 1

                }


                //comprueba si la production ya está asignada a el director, si no está asignada la asigna
                if (this.#getProductionPosition(production, this.#directors[directorP].products) === -1)
                    this.#directors[directorP].products.push(this.#productions[productionP]);


                //Retornamos la longitud del array interno de products
                return this.#directors[directorP].products.length;
            }



            //Función para deasignar un director del VideoSystem
            deassignDirector(director, production) {


                //Comprobamos las instancias de los parámetros
                if (!(director instanceof Person)) throw new InvalidTypeException();

                if (!(production instanceof Production)) throw new InvalidTypeException();


                //Obtenemos las posiciones tanto del director como de las production en sus arrays
                let directorP = this.#getDirectorPosition(director);

                let pro = this.#directors[directorP].products;

                let productionP = this.#getProductionPosition(production, pro);


                //Si el director existe en el array
                if (directorP !== -1) {
                    //Comprobamos que la producción también exista
                    if (productionP !== -1) {
                        //Y en ese caso lo deasignamos
                        this.#directors[directorP].products.splice(productionP, 1)
                    } else {
                        //Lanzamos una excepción si la producción no existe
                        throw NotExistedElementException();
                    }

                } else {
                    //Lanzamos una excepción si el director no existe
                    throw NotExistedElementException();
                }

                //Retornamos la longitud del array interno de producciones de directores
                return this.#directors[directorP].products.length;

            }




            //Función para asignar actores al VideoSystem
            assignActors(actors, production) {


                if (!(production instanceof Production)) throw new InvalidTypeException();

                //Guardamos en una varible la lista de producciones
                let pro = this.#productions;

                for (let i = 0; i < actors.length; i++) {

                    let actorP = this.#getActorPosition(actors[i]);

                    let productionP = this.#getProductionPosition(production, pro);


                    //Si la posición es -1 es que no existe, por lo que tenemos que añadir con un add
                    // y le damos a la position el último valor ya que hemos añadido ese valor y será el último
                    //en la lista
                    if (actorP === -1) {
                        this.addActor(actors[i]);
                        actorP = this.#actors.length - 1

                    }

                    if (productionP === -1) {
                        this.addProduction(production);
                        productionP = this.#productions.length - 1

                    }


                    //comprueba si la production ya está asignada a el actor, si no está asignada la asigna
                    if (this.#getProductionPosition(production, this.#actors[actorP].products) === -1)
                        this.#actors[actorP].products.push(this.#productions[productionP]);

                }
                //Obtenemos las posiciones tanto del actor como de las production en sus arrays


            }



            //Función para deasignar un actor del VideoSystem
            deassignActor(actor, production) {


                //Comprobamos las instancias de los parámetros
                if (!(actor instanceof Person)) throw new InvalidTypeException();

                if (!(production instanceof Production)) throw new InvalidTypeException();



                //Obtenemos las posiciones tanto del actor como de las production en sus arrays
                let actorP = this.#getActorPosition(actor);

                let pro = this.#actors[actorP].products;

                let productionP = this.#getProductionPosition(production, pro);


                //Si el actor existe en el array
                if (actorP !== -1) {
                    //Comprobamos que la producción también exista
                    if (productionP !== -1) {
                        //Y en ese caso lo deasignamos
                        this.#actors[actorP].products.splice(productionP, 1)
                    } else {
                        //Lanzamos una excepción si la producción no existe
                        throw new NotExistedElementException();
                    }

                } else {
                    //Lanzamos una excepción si la categoria no existe
                    throw new NotExistedElementException();
                }

                //Retornamos la longitud del array interno de producciones de actores
                return this.#actors[actorP].products.length;

            }

            //Metodo para que nos devuelva la categoria del titulo que le pasamos
            getCategory(title) {

                let cat;

                for (let i = 0; i < this.#categories.length; i++) {
                    //Comparamos el titulo que le pasamos con el nombre de la categoria 
                    if (this.#categories[i].category.name === title) {
                        cat = this.#categories[i];

                    }
                }

                return cat;
            }


            // //Retornamos el objeto iterador para retornar el casting de toda la producción
            * getCast(production) {

                //Comprobamos las instancias de los parámetros
                if ((production == null) || (!(production instanceof Production))) throw new InvalidTypeException();

                //Declaramos una variable y le damos como valor el array de actores, guardando también su referencia
                let list = this.#actors;

                // Con este for of recorremos todos los elementos y los devolvemos uno por uno con el yield
                for (let ac of list) {

                    let cont = 0;

                    let actor = null;

                    // Mientras no se encuentre el actor se sigue recorriendo el array
                    while (cont < ac.products.length && !actor) {

                        //Comparamos por las fotos
                        if (ac.products[cont].title === production.title) {
                            yield ac.actor;
                        }
                        cont++;
                    }

                }


            }


            // //Retornamos el objeto iterador para retornar el casting de toda la producción
            * getDirs(production) {

                //Comprobamos las instancias de los parámetros
                if ((production == null) || (!(production instanceof Production))) throw new InvalidTypeException();

                //Declaramos una variable y le damos como valor el array de actores, guardando también su referencia
                let list = this.#directors;

                // Con este for of recorremos todos los elementos y los devolvemos uno por uno con el yield
                for (let di of list) {

                    let cont = 0;

                    let director = null;

                    // Mientras no se encuentre el actor se sigue recorriendo el array
                    while (cont < di.products.length && !director) {

                        //Comparamos por las fotos
                        if (di.products[cont].title === production.title) {
                            yield di.director;
                        }
                        cont++;
                    }

                }


            }


            // //Retornamos el objeto iterador para retornar el casting de toda la producción
            getActors(production) {

                // //Comprobamos las instancias de los parámetros
                if ((production == null) || (!(production instanceof Production))) throw new InvalidTypeException();

                //Declaramos una variable y le damos como valor el array de actores, guardando también su referencia
                let list = this.#actors;

                let act = [];

                // Con este for of recorremos todos los elementos y los devolvemos uno por uno con el yield
                for (let ac of list) {

                    let cont = 0;

                    let actor = null;

                    // Mientras no se encuentre el actor se sigue recorriendo el array
                    while (cont < ac.products.length && !actor) {

                        //Comparamos por las fotos
                        if (ac.products[cont].title === production.title) {
                            actor = ac.actor;
                            console.log(ac.actor)
                            act.push(actor);
                        }
                        cont++;

                    }

                    //Si encuentra el actor lo devuelve
                    //     / if (actor) yield actor;
                    return act;

                }



            }


            // //Retornamos el objeto iterador para retornar el casting de toda la producción
            getDirector(name) {

                //Declaramos una variable y le damos como valor el array de actores, guardando también su referencia
                let list = this.#directors;

                for (let i = 0; i < list.length; i++) {
                    let full = list[i].director.name + " " + list[i].director.lastname1;
                    //Comparamos por las fotos
                    if ((full) === name) {
                        return (list[i]);
                    }
                }
            }


            // //Retornamos el objeto iterador para retornar el casting de toda la producción
            getActor(name) {

                //Declaramos una variable y le damos como valor el array de actores, guardando también su referencia
                let list = this.#actors;

                for (let i = 0; i < list.length; i++) {
                    let full = list[i].actor.name + " " + list[i].actor.lastname1;
                    //Comparamos por las fotos
                    if ((full) === name) {
                        return (list[i]);
                    }
                }


            }


            // //Retornamos el objeto iterador para recuperar los directores
            * getProductionsDirector(director) {


                //Comprobamos las instancias de los parámetros
                if ((director == null) || (!(director instanceof Person))) throw new InvalidTypeException();

                //Declaramos una variable y le damos como valor la posición del director que le pasamos
                let directorP = this.#getDirectorPosition(director);

                //Si no existe lanzamos excepción
                if (directorP === -1) throw new NotExistedElementException();

                //Declaramos una variable y le damos como valor el array interno de products de directoes en la posición del director que le pasamos
                let list = this.#directors[directorP].products;

                //Con este for of recorremos todos los elementos y los devolvemos uno por uno con el yield
                for (let direc of list) {
                    yield direc;
                }

            }


            // //Retornamos el objeto iterador para recuperar los
            * getProductionsActor(actor) {

                //Comprobamos las instancias de los parámetros
                if ((actor == null) || (!(actor instanceof Person))) throw new InvalidTypeException();

                //Declaramos una variable y le damos como valor la posición del actor que le pasamos
                let actorP = this.#getActorPosition(actor);

                //Si el actor no existe lanzamos una excepción
                if (actorP === -1) throw new NotExistedElementException();

                //Declaramos una variable y le damos como valor el array interno de products de la lista de actores
                let list = this.#actors[actorP].products;

                //Con este for of recorremos todos los elementos y los devolvemos uno por uno con el yield
                for (let ac of list) {
                    yield ac;
                }
            }


            //Retornamos el objeto iterador para recuperar las categorias
            * getProductionsCategory(category) {

                //Comprobamos las instancias de los parámetros
                if (!(category instanceof Category)) throw new InvalidTypeException();

                //Declaramos una variable y le damos como valor la posición de la categoria que le pasamos
                let categoryP = this.#getCategoryPosition(category);

                //Si la categoria no existe lanzamos una excepción
                if (categoryP === -1) throw new NotExistedElementException();

                //Declaramos una variable y le damos como valor el array interno de products
                let list = this.#categories[categoryP].products;

                //Con este for of recorremos todos los elementos y los devolvemos uno por uno con el yield
                for (let cat of list) {
                    yield cat;
                }
            }

            //Función para generar 3 numeros aleatorios que serán las producciones
            //que se pondrán aleatoriamente en el carousel
            randomNumber() {

                let randoms = [];

                do {
                    let numeroAleatorio = Math.floor(Math.random() * 12) + 0;
                    if (!randoms.includes(numeroAleatorio)) {
                        randoms.push(numeroAleatorio);
                    }
                } while (randoms.length < 3);

                return randoms;
            }


        }

        let sc = new VideoSystem(name);//Devolvemos el objeto VideoSystem para que sea una instancia única.
        //Congelamos el objeto
        Object.freeze(sc);
        //Retornamos el objeto
        return sc;
    }

    return {
        getInstance: function (name) {
            if (!instatiated) { //Si instantiated es undefined llama a init.
                instatiated = init(name); //instantiated contiene el objeto único
            }
            return instatiated; //Devuelve el campo privado
        }
    }
})();

//Exportamos todas las clases para poder meterlas en el testeo
export default VideoSystem;

//Exportamos todas las excepciones
export {
    AbstractClassException, EmptyValueException,
    ExistedElementException, NotExistedElementException,
    InvalidTypeException, InvalidLatitudeException, InvalidLongitudeException,
    InvalidEmailException
}

