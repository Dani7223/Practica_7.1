import { Category, Movie, Resource, Serie, Person } from "../entities/productions.js";

class VideoSystemView {
  constructor() {
    this.main = $('main');
    this.cards = $('#card1');
    this.categories = $('#categories');
    this.navbar = $('#navbar');

  }


  #executeHandler(
    handler, handlerArguments, scrollElement, data, url, event) {
    handler(...handlerArguments);
    $(scrollElement).get(0).scrollIntoView();
    history.pushState(data, null, url);
    event.preventDefault();
  }



  //Función que nos muestra la página principal de la web
  init(pros, cats) {

    let car = "";

    let cadena = "";

    let cont = 0;

    this.main.empty();

    //Con este foreach que los valores serán aleatorios
    //tendremos un carrousel aleatorio de producciones
    pros.forEach(function (element) {
      if (cont == 0) {
        car = (`    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">
        <div class="carousel-indicators">
          <button type="button" id="flechas" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" id="flechas" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" id="flechas" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
    
        <div class="carousel-inner" id='caru'> 

        <div class="carousel-item active">
        <a href='#car' data-type='${element.title}'>
        <img src="./img/${element.image}" class="d-block mx-auto w-50 h-70" alt="production1">
        <div class="carousel-caption d-none d-md-block">
          <h5>${element.title}</h5>
          <p>${element.publication}</p>
        </div>
        </a>
        </div> `)
      } else {
        car = (`<div class="carousel-item">
        <a href='#' data-type='${element.title}'>
        <img src="./img/${element.image}" class="d-block mx-auto w-50 h-70" alt="production2">
        <div class="carousel-caption d-none d-md-block">
        <h5>${element.title}</h5>
        <p>${element.publication}</p>
        </div>
        </a>
        </div> `)
      }

      cadena += car;
      cont++;

    });


    this.main.append(cadena)


    this.main.append(`</div>
    
    <button id="flecha" class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button id="flecha" class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>

  <div class="container">
  <div class="row margin" id="categories">


  </div>
  </div>

    `);



    for (const cat of cats) {
      $('#categories').append(`<div class="col-md-4 gap-5 mb-3" id='card1' >
      
      <div class="bg-secondary">
      <a href='#cat' id='cards' data-type="${cat.category.name}">
      <img src="/img/${cat.category.image}" class="card-img-top" alt="${cat.category.name}">
      
        <h5 class="card-title text-light">${cat.category.name}</h5>
        <p class="card-text text-light">Todas las novedades en taquilla de las péliculas con mas acción del momento</p>
        <p class="card-text text-light"><small class="text-light">Actualizado hace 2 dias</small></p>
      
      </a>
      </div>
      </div>

    
   `);
    }


  }

  //Bind para mostrar una pelicula individual desde el carrousel
  bindCarousel(handler) {
    let manejador = this.#executeHandler;
    $('#caru').children().find('a').click(function (event) {
      let serial = $(event.target).closest($('a')).get(0).dataset.type;
      manejador(
        handler, [serial],
        'main',
        { action: 'showCarPro', serial: serial },
        '#car', event
      );

    });
  }

  //Bind para mostrar todas las peliculas de una categoria
  bindShowMovies(handler) {
    $('#categories').find('a').click((event) => {
      let category =
        $(event.target).closest($('a')).get(0).dataset.type;
      this.#executeHandler(
        handler, [category],
        'main',
        { action: 'showInit', category: category },
        '#categories', event
      );
    });
  }



  //Función para mostrar un mensaje modal al añadir una categoria
  addModalCat(category) {

    let mod = $(`<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Operación conseguida</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
         La categoria ${category.name} ha sido creada con éxito
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>`);


    $('body').append(mod);

    let modal = $('#myModal');

    modal.modal('show')

    modal.find('button').click(() => {
      modal.modal('hide');
      modal.remove();
      document.getElementById('formCat').reset();

    });

  }

  assignModalAct() {
    let mod = $(`<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Operación conseguida</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        Los actores han sidos asignados correctamente
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>`);


    $('body').append(mod);

    let modal = $('#myModal');

    modal.modal('show')

    modal.find('button').click(() => {
      modal.modal('hide');
      modal.remove();
      document.getElementById('asiAct').reset();

    });

  }



  assignModalDir() {
    let mod = $(`<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Operación conseguida</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        Los directores han sidos asignados correctamente
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>`);


    $('body').append(mod);

    let modal = $('#myModal');

    modal.modal('show')

    modal.find('button').click(() => {
      modal.modal('hide');
      modal.remove();
      document.getElementById('asiDir').reset();

    });

  }

  //Función para mostrar un mensaje modal al añadir una categoria
  addModalPer(person, rol) {

    let mod = "";

    if (rol == "Both") {
      mod = $(`<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Operación conseguida</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
             El actor y director ${person.name} ${person.lastname1} ha sido creado con éxito
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-success" data-dismiss="modal">Cerrar</button>
            </div>
          </div>
        </div>
      </div>`);
    } else if (rol == "Act") {
      mod = $(`<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Operación conseguida</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
           El actor ${person.name} ${person.lastname1} ha sido creado con éxito
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-success" data-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>`);
    } else if (rol = "Dir") {
      mod = $(`<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Operación conseguida</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
           El director ${person.name} ${person.lastname1} ha sido creado con éxito
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-success" data-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>`);
    }


    $('body').append(mod);

    let modal = $('#myModal');

    modal.modal('show')

    modal.find('button').click(() => {
      modal.modal('hide');
      modal.remove();
      document.getElementById('formPer').reset();

    });

  }



  //Función para mostrar un mensaje modal al añadir una categoria
  addModalPro(production) {

    let mod = "";

    if (production instanceof Serie) {
      mod = $(`<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Operación conseguida</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
           La serie ${production.title} ha sido creada con éxito
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-success" data-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>`);

    } else if (production instanceof Movie) {
      mod = $(`<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Operación conseguida</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
           La película ${production.title} ha sido creada con éxito
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-success" data-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>`);
    }




    $('body').append(mod);

    let modal = $('#myModal');

    modal.modal('show')

    modal.find('button').click(() => {
      modal.modal('hide');
      modal.remove();
      document.getElementById('formPro').reset();

    });

  }


  //Función para mostrar un mensaje modal al añadir una categoria
  delModalCat(cate) {

    let mod = $(`<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Operación conseguida</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
         La categoria ${cate.category.name} ha sido borrada con éxito
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>`);


    $('body').append(mod);

    let modal = $('#myModal');

    modal.modal('show')

    modal.find('button').click(() => {
      modal.modal('hide');
      modal.remove();
      document.getElementById('delCat').reset();

    });

  }


  //Función para mostrar un mensaje modal al añadir una categoria
  delModalPer() {

    let mod = $(`<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Operación conseguida</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
          Todos las personas han sido borradas correctamente
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-success" data-dismiss="modal">Cerrar</button>
          </div>
        </div>
      </div>
    </div>`);


    $('body').append(mod);

    let modal = $('#myModal');

    modal.modal('show')

    modal.find('button').click(() => {
      modal.modal('hide');
      modal.remove();
      document.getElementById('delPer').reset();

    });

  }




  //Función para mostrar un mensaje modal al añadir una categoria
  delModalPro() {

    let mod = $(`<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Operación conseguida</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
            Todas las producciones han sido borradas con éxito
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-success" data-dismiss="modal">Cerrar</button>
            </div>
          </div>
        </div>
      </div>`);


    $('body').append(mod);

    let modal = $('#myModal');

    modal.modal('show')

    modal.find('button').click(() => {
      modal.modal('hide');
      modal.remove();


    });

  }


  //Función para mostrar un mensaje modal al añadir una categoria
  delModalCatError() {

    let mod = $(`<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Operación conseguida</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
         Esa categoria no existe!!
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>`);


    $('body').append(mod);

    let modal = $('#myModal');

    modal.modal('show')

    modal.find('button').click(() => {
      modal.modal('hide');
      modal.remove();
      document.getElementById('delCat').reset();


    });

  }


  //Función para mostrar un mensaje modal al añadir una categoria
  modalDeaActor(acts, products) {

    $('body').append(`<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Operación conseguida</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        
          <div class="modal-body" id='modal'>
           Produccion: ${products.title}
           <br>
           </div>

           <div class="modal-footer">
           <button type="button" class="btn btn-success" data-dismiss="modal">Cerrar</button>
         </div>
       </div>
     </div>
   </div>
          `);

    for (let i = 0; i < acts.length; i++) {
      $('#modal').append(`El actor ` + acts[i].actor.name + " " + acts[i].actor.lastname1 + ` ha sido deasignado con exito`)

    }

    let modal = $('#myModal');

    modal.modal('show')

    modal.find('button').click(() => {
      modal.modal('hide');
      modal.remove();


    });

  }


  //Función para mostrar un mensaje modal al añadir una categoria
  modalDeaDirector(dirs, products) {

    $('body').append(`<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Operación conseguida</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          
            <div class="modal-body" id='modal'>
             Produccion: ${products.title}
             <br>
             </div>
  
             <div class="modal-footer">
             <button type="button" class="btn btn-success" data-dismiss="modal">Cerrar</button>
           </div>
         </div>
       </div>
     </div>
            `);

    for (let i = 0; i < dirs.length; i++) {
      $('#modal').append(`El director ` + dirs[i].director.name + " " + dirs[i].director.lastname1 + ` ha sido deasignado con exito`)

    }

    let modal = $('#myModal');

    modal.modal('show')

    modal.find('button').click(() => {
      modal.modal('hide');
      modal.remove();


    });

  }




  //Función para mostrar todas las categorias que tenemos en la barra de navegación
  showCategoriesNavbar(categories) {
    this.navbar.empty();

    let li = $(`<li id='cats' class="nav-item dropdown">
			<a class="nav-link dropdown-toggle text-white" href="#" id="navCats" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Categorías
			</a>
		</li>`);
    let container = $('<div class="dropdown-menu" aria-labelledby="navCats"></div>');

    for (const iterator of categories) {
      container.append(`<a data-category="${iterator.category.name}" class="dropdown-item" href="#productlist">${iterator.category.name}</a>`);
    }
    li.append(container);
    this.navbar.append(li);
  }


  //Función para mostrar todas los actores que tenemos en la barra de navegación
  showActorsNavbar(actors) {
    let li = $(`<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle text-white" href="#" id="navAct" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Actores
			</a>
		</li>`);
    let container = $('<div class="dropdown-menu" aria-labelledby="navAct" id="actor"></div>');

    for (const iterator of actors) {
      container.append(`<a data-category="${iterator.actor.name} ${iterator.actor.lastname1}" class="dropdown-item" href="#productlist" id="act">${iterator.actor.name} ${iterator.actor.lastname1}</a>`);
    }
    li.append(container);
    this.navbar.append(li);
  }

  //Función para mostrar todas los directores que tenemos en la barra de navegación
  showDirectorsNavbar(directors) {
    let li = $(`<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle text-white" href="#" id="navDir" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Directores
			</a>
		</li>`);
    let container = $('<div class="dropdown-menu" aria-labelledby="navDir" id="director"></div>');

    for (const iterator of directors) {
      container.append(`<a data-category="${iterator.director.name} ${iterator.director.lastname1}" class="di dropdown-item" href="#productlist" id="di">${iterator.director.name} ${iterator.director.lastname1}</a>`);
    }
    li.append(container);
    this.navbar.append(li);
  }

  //Función para mostrar todas las categorias que tenemos en la barra de navegación
  showAddNavbar() {
    let li = $(`<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle text-white" href="#" id="navAdd" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Añadir
			</a>
		</li>`);
    let container = $('<div class="dropdown-menu" aria-labelledby="navAdd"></div>');

    container.append(`<a data-category="Produ" class="dropdown-item" href="#productlist">Producción</a>`);
    container.append(`<a data-category="Cat" class="dropdown-item" href="#productlist">Categoria</a>`);
    container.append(`<a data-category="Per" class="dropdown-item" href="#productlist">Person</a>`);

    li.append(container);
    this.navbar.append(li);
  }


  //Función para mostrar todas las categorias que tenemos en la barra de navegación
  showRemoveNavbar() {
    let li = $(`<li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle text-white" href="#" id="navRem" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Eliminar
        </a>
      </li>`);
    let container = $('<div class="dropdown-menu" aria-labelledby="navRem"></div>');

    container.append(`<a data-category="Produ" class="dropdown-item" href="#">Producción</a>`);
    container.append(`<a data-category="Cat" class="dropdown-item" href="#">Categoria</a>`);
    container.append(`<a data-category="Per" class="dropdown-item" href="#">Person</a>`);

    li.append(container);
    this.navbar.append(li);
  }


  //Función para mostrar todas las categorias que tenemos en la barra de navegación
  showAssignNavbar() {
    let li = $(`<li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-white" href="#" id="navAsi" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Asignar
          </a>
        </li>`);
    let container = $('<div class="dropdown-menu" aria-labelledby="navAsi"></div>');

    container.append(`<a data-category="Act" class="dropdown-item" href="#">Actor</a>`);
    container.append(`<a data-category="Dir" class="dropdown-item" href="#">Director</a>`);

    li.append(container);
    this.navbar.append(li);
  }


  //Función para mostrar todas las categorias que tenemos en la barra de navegación
  showDeassignNavbar() {
    let li = $(`<li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle text-white" href="#" id="navDAsi" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Deasignar
            </a>
          </li>`);
    let container = $('<div class="dropdown-menu" aria-labelledby="navDAsi"></div>');

    container.append(`<a data-category="Act" class="dropdown-item" href="#">Actor</a>`);
    container.append(`<a data-category="Dir" class="dropdown-item" href="#">Director</a>`);

    li.append(container);
    this.navbar.append(li);
  }

  //Bind que nos muestra todas las películas de una categoria desde el navbar
  bindProductsCategoryNavbar(handler) {
    $('#navCats').next().children().click((event) => {
      let category =
        $(event.target).closest($('a')).get(0).dataset.category;
      this.#executeHandler(
        handler, [category],
        'main',
        { action: 'showInit', category: category },
        '#categories', event
      );

    });
  }

  //Bind para cuando pinchemos en los directores pero en la barra de navegación
  bindProductsDirectorsNavbar(handler) {
    let manejador = this.#executeHandler;
    $('#navDir').next().children().click(function (event) {
      let category =
        $(event.target).closest($('a')).get(0).dataset.category;
      manejador(
        handler, [category],
        'main',
        { action: 'showDirectorNav', category: category },
        '#dir', event
      );
    })
  }

  //Bind para mostrar un actor individual
  bindSingleActor(handler) {
    let manejador = this.#executeHandler;
    $('#navAct').next().children().click(function (event) {
      let category =
        $(event.target).closest($('a')).get(0).dataset.category;
      manejador(
        handler, [category],
        'main',
        { action: 'showActor', category: category },
        '#act', event
      );
    });
  }

  bindAddNavbar(handler) {
    let manejador = this.#executeHandler;
    $('#navAdd').next().children().click(function (event) {
      let category =
        $(event.target).closest($('a')).get(0).dataset.category;
      manejador(
        handler, [category],
        'main',
        { action: 'showAddForm', category: category },
        '#add', event
      );
    });
  }


  bindRemoveNavbar(handler) {
    let manejador = this.#executeHandler;
    $('#navRem').next().children().click(function (event) {

      let category = $(event.target).closest($('a')).get(0).dataset.category;

      manejador(
        handler, [category],
        'main',
        { action: 'showRemoveForm', category: category },
        '#remove', event
      );
    });
  }

  bindAssignNavbar(handler) {
    let manejador = this.#executeHandler;
    $('#navAsi').next().children().click(function (event) {

      let category = $(event.target).closest($('a')).get(0).dataset.category;

      manejador(
        handler, [category],
        'main',
        { action: 'showAssignForm', category: category },
        '#assign', event
      );
    });
  }

  bindDessignNavbar(handler) {
    let manejador = this.#executeHandler;
    $('#navDAsi').next().children().click(function (event) {

      let category = $(event.target).closest($('a')).get(0).dataset.category;

      manejador(
        handler, [category],
        'main',
        { action: 'showDeassignForm', category: category },
        '#deassign', event
      );
    });
  }

  //Función que nos muetra las producciones que tiene una categoria, una por una
  showMovies(movies, title) {
    this.main.empty();
    if (this.categories.children().length > 1)
      this.categories.children()[1].remove();
    let container = $("<div id='product-list' class='container my-4'><div id='gap' class='row row-cols-md-2'> </div></div>");
    let movie = movies.next();
    let type = "";


    //Recorremos todas las producciones
    while (!movie.done) {

      //Mostramos al lado de la pelicula si es una serie o una pelicula
      if (movie.value instanceof Serie) {
        type = "Serie";
      } else if (movie.value instanceof Movie) {
        type = "Pelicula"
      }

      //Mostramos la pelicula
      let div = $(`
      <div class="col">
      
      <figure class='card card-product-grid card-lg'> <a data-serial='${movie.value.title}'  class='img-wrap'><img class='${movie.value.constructor.name}-style rounded mx-auto d-block' src='./img/${movie.value.image}' id='pelis'></a>
      <figcaption class='info-wrap'>
      <div id="peli" class='row'>
        <div id="synopsis" class='col-md-8 text-dark'> <h1 data-serial='${movie.value.title}' 
         class='title'>${movie.value.title} - ${type}</h1> <br> ${movie.value.synopsis}</div>
        <div class='col-md-4'>
        
          <div class='rating text-right'> <i class='fa fa-star'></i> <i class='fa fa-star'></i> <i class='fa fa-star'></i> </div>
        </div>
        
      </div>
    </figcaption>

    

    <div id="watch" class='bottom-wrap'>    
    <a href='#movie' id='single' data-serial='${movie.value.title}' class='btn btn-primary float prueba'> Ver </a>
    </div>
    <div class='price-wrap'> <span class='price h5'></span> <br> <small class='text-success'>Introducida hace poco</small> </div>
  </div>
</figure>
        </div>
        </a>
    `);
      container.children().first().append(div);
      movie = movies.next();
    }
    container.prepend(`<h1>${title}</h1>`);
    this.main.append(container);

  }

  //Bind para iniciar la pagina
  bindInit(handler) {
    $('#init').click((event) => {
      handler();
      this.#executeHandler(handler, [], 'body', { action: 'init' }, '#', event);

    });

  }


  showAddForm(type, actors, directors, categorias) {
    this.main.empty();


    if (type == "Produ") {
      this.main.append(`<div class="container">
      <h2>Añadir producción</h2>
  

  
     
      <form id="formPro" role="form" novalidate>


      <div class="form-group">
<label for="type">Selecciona tipo de producción:</label>
<select class="form-select-sm" id="type" required>
<option value=""></option>
  <option value="Serie">Serie</option>
  <option value="Movie">Pelicula</option>
</select>
<div class="invalid-feedback text-warning">Debes seleccionar una producción</div>
<div class="valid-feedback">Correcto</div>
</div>

      <div class="d-flex justify-content-center gap-4">

      <div>
        <label for="title" class="form-label">Titulo:</label>
        <input type="text" class="form-control-sm" id="title" placeholder="Titulo de la producción" required>
        <div class="invalid-feedback text-warning ">Este campo no puede estar vacio!</div>
         <div class="valid-feedback ">Correcto</div>
      </div>

      <div>
      <label for="nacion" class="form-label">Nacionalidad:</label>
      <input type="text" class="form-control-sm" id="nacion" placeholder="Nacionalidad de la produ" required pattern="[A-Z,a-z]{1,60}">
      <div class="invalid-feedback text-warning ">Escriba bien la nacionalidad!(solo letras)</div>
      <div class="valid-feedback ">Correcto</div>
      </div>

      <div>
      <label for="year" class="form-label">Año publicación:</label>
      <input type="text" class="form-control-sm" id="year" placeholder="Año de la produccion" required pattern='[0-9]{4}'>
      <div class="invalid-feedback text-warning ">Año incorrecto!!</div>
      <div class="valid-feedback ">Correcto</div>
      </div> 
    
    <div>
<label for="img" class="form-label">Image URL:</label>
<input type="file" class="form-control-sm" id="img" placeholder="Ej: ./img/example.png"  required>
<div class="invalid-feedback text-warning ">Debe subir una foto para la produccion!!</div>
<div class="valid-feedback ">Correcto</div>
</div> 
    </div>  

 

<div class="d-flex justify-content-center mt-5">
<label for="syn" class="form-label">Synopsis:</label>
<input type="text" class="form-control" id="syn" placeholder="Escriba la synopsis de la producción"  required>
<div class="invalid-feedback text-warning ">Escriba una synopsis reducida sobre la producción</div>
<div class="valid-feedback ">Correcto</div>
</div>

<div id='change' class='d-flex justify-content-center mt-5 gap-4'>


</div>

<div class="row">

<div class="col-md-4">

 <label for="cat2" class="form-label">Categorias:</label>
     <div class='form-group gap-5'>
     <select id='cat2' class="form-select-sm custom-select" multiple aria-label="multiple select example" required>

     </select>
     <div class="invalid-feedback text-warning ">Debe seleccionar al menos una categoria!!</div>
    <div class="valid-feedback ">Correcto</div>
     </div>
     </div>


     <div class="col-md-4">
<label for="act2" class="form-label">Actores:</label>
     <div class='form-group gap-5'>
     <select id='act2' class="form-select-sm" multiple aria-label="multiple select example">
     </select>
     </div>
     </div>


     <div class="col-md-4">
     <label for="dir2" class="form-label">Director:</label>
     <div class='form-group'>
     <select id='dir2' class="form-select-sm" aria-label="select example">
     </select>
     </div>
     </div>
</div>
      <div class="d-flex justify-content-center">
      <button type="submit" class="btn btn-outline-info mt-4">Crear</button>
      </div>
      </form>
  `);

      for (const act of actors) {
        let actores = `<option value="${act.actor.name} ${act.actor.lastname1}">${act.actor.name} ${act.actor.lastname1}</option>`;

        $('#act2').append(actores)
      }


      for (const dir of directors) {
        let directores = `<option value="${dir.director.name} ${dir.director.lastname1}">${dir.director.name} ${dir.director.lastname1}</option>`;


        $('#dir2').append(directores)

      };

      for (const cat of categorias) {
        let cate = `<option value="${cat.category.name}">${cat.category.name}</option>`;


        $('#cat2').append(cate)

      }

      const selectOption = document.getElementById('type');
      selectOption.addEventListener('change', function () {
        const selectedValue = selectOption.value;

        if (selectedValue === 'Serie') {
          $('#change').empty();
          $('#change').append(`
          <div>
          <label for="season" class="form-label">Temporadas:</label>
          <input type="text" class="form-control-sm" id="season" placeholder="Temporadas de la serie"  required pattern="[1-9]{1,2}">
          <div class="invalid-feedback text-warning ">Debe escribir el número de temporadas</div>
          <div class="valid-feedback ">Correcto</div>
          </div>

        <div>
  <label for="locX" class="form-label">Locations (X):</label>
  <input type="text" class="form-control-sm" id="locX" placeholder="Coordenadas X" required pattern="-?[0-9]{1,9}">
  <div class="invalid-feedback text-warning ">Introducce bien las coordenadas X</div>
  <div class="valid-feedback ">Correcto</div>
  </div>

<div>
<label for="locY" class="form-label">Locations (Y):</label>
<input type="text" class="form-control-sm" id="locY" placeholder="Coordenadas Y" required pattern="-?[0-9]{1,9}">
<div class="invalid-feedback text-warning ">Introducce bien las coordenadas Y</div>
<div class="valid-feedback ">Correcto</div>
</div>

          <div>
          <label for="resources" class="form-label">Recursos:</label>
          <input type="text" class="form-control-sm" id="resources" placeholder="Recurso de la serie" required>
          <div class="invalid-feedback text-warning ">Introduzca el recurso de la serie</div>
<div class="valid-feedback ">Correcto</div>
        </div>
        </form>

         `)



        } else if (selectedValue === 'Movie') {
          $('#change').empty();
          $('#change').append(`
          <div>
          <label for="locX" class="form-label">Localización(X):</label>
          <input type="text" class="form-control" id="locX" placeholder="Coordenada X" required pattern="-?[0-9]{1,9}">
          <div class="invalid-feedback text-warning ">Introducce bien las coordenadas X</div>
<div class="valid-feedback ">Correcto</div>
          </div>

        <div>
        <label for="locY" class="form-label">Localización(Y)</label>
        <input type="text" class="form-control" id="locY" placeholder="Coordenada Y"  required pattern="-?[0-9]{1,9}">
        <div class="invalid-feedback text-warning ">Introducce bien las coordenadas Y</div>
        <div class="valid-feedback ">Correcto</div>
        </div>

        <div>
  <label for="dur" class="form-label">Duracion:</label>
  <input type="text" class="form-control" id="dur" placeholder="ej: 2h 55m"  required pattern="[0-9]{1}h [0-9]{1,2}m">
  <div class="invalid-feedback text-warning ">Escriba bien la duración</div>
  <div class="valid-feedback ">Correcto</div>
  </div>

<div>
<label for="link" class="form-label">Link:</label>
<input type="text" class="form-control" id="link" placeholder="www.pelicula.es"  required>
<div class="invalid-feedback text-warning ">Introduzca el link</div>
<div class="valid-feedback ">Correcto</div>
</div>
</form>

         `)

        }

      });

    } else if (type == "Cat") {

      let div = (`
      <form id='formCat' novalidate>

      <div class="container">
      <h2>Añadir categoria</h2>
    <div class="row">
      <div class="col-md-6">
        <label for="name" class="form-label">Nombre:</label>
        <input type="text" class="form-control" id="name" placeholder="Nombre de la categoria" required pattern="[A-Z,a-z]{3,30}">
        <div class="invalid-feedback text-warning">Introduzca un nombre correcto</div>
        <div class="valid-feedback">Correcto.</div>
      </div>
      <div class="col-md-6">
      <label for="des" class="form-label">Descripción:</label>
<input type="text" class="form-control" id="des" placeholder="Descripción de la categoria" required>
<div class="invalid-feedback text-warning">Introduzca una descripción de la categoria</div>
<div class="valid-feedback">Correcto.</div>
</div>

</div>

</div>

<div class=" mt-5" id='contenido'>
<label for="img" class="form-label">Imagen de la categoria:</label>
<input type="file" class="form-control-sm" id="img" placeholder="Ej: ./img/example.png"  required>
<div class="invalid-feedback text-warning">Seleccione una foto</div>

</div> 

<div class="d-flex justify-content-center mt-5">
<button type="submit" id='createCat' class="btn btn-primary">Crear</button>
</div>
</form>
  
  `)

      this.main.append(div);



    } else if (type == "Per") {

      let div = (`
      <form id='formPer' novalidate>
      <div class="container">
      <h2>Añadir persona</h2>
    <div class="row">
      <div class="col-md-6">
        <label for="name" class="form-label">Nombre:</label>
        <input type="text" class="form-control" id="name" placeholder="Nombre de la persona" required pattern="[A-Z,a-z]{2,30}">
        <div class="invalid-feedback text-warning">Rellene el nombre correctamente</div>
<div class="valid-feedback">Correcto.</div>
      </div>
      <div class="col-md-6">
      <label for="last1" class="form-label">Primer apellido:</label>
<input type="text" class="form-control" id="last1" placeholder="Primer apellido de la persona" required pattern="[A-Z,a-z]{2,30}">
<div class="invalid-feedback text-warning">Rellene el nombre correctamente</div>
<div class="valid-feedback">Correcto.</div>
</div>

</div>


<div class="row">
<div class="col-md-6">
  <label for="last2" class="form-label">Segundo apellido(opcional):</label>
  <input type="text" class="form-control" id="last2" placeholder="Segundo apellido de la persona">
</div>
<div class="col-md-6">
<label for="year" class="form-label">Fecha de nacimiento:</label>
<input type="text" class="form-control" id="year" placeholder="ej: 23/01/2002" required pattern="[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}">
<div class="invalid-feedback text-warning">Escribe correctamente la fecha</div>
<div class="valid-feedback">Correcto.</div>
</div>

</div>


<div class="row">
<div class="col-md-6">
  <label for="img" class="form-label">Foto:</label>
  <input type="file" class="form-control-sm mt-5" id="img" placeholder="Foto de la persona" required>
  <div class="invalid-feedback text-warning">La foto es obligatoria!!</div>
<div class="valid-feedback">Correcto.</div>
</div>

<div class="col-md-6">
<label for="rol">Selecciona su rol o roles:</label>
<select class="form-select-sm mt-3" multiple id="rol" required>
  <option value="Actor">Actor</option>
  <option value="Director">Director</option>
</select>
<div class="invalid-feedback text-warning">Al menos un rol es obligatorio</div>
<div class="valid-feedback">Correcto.</div>
</div>

</div>

<div class="d-flex justify-content-center mt-5">
<button type="submit" id='createCat' class="btn btn-primary">Crear</button>
</div>
</form>
  </div>
  `)

      this.main.append(div);

    }


  }


  //Bind para recibir los datos del formulario de la categoria
  //crear una categoria y mandarla en el handler
  bindFormCategoryD(handler) {

    document.getElementById('delCat').addEventListener("submit", function (event) {

      $("#delCat").addClass('was-validated');

      if (this.checkValidity() === false) {
        event.preventDefault();
        event.stopPropagation();
      } else {
        let cate = (document.getElementById('cat').value)

        handler(cate)
      }

    });

  }


  //Bind para recibir los datos del formulario de la categoria
  //crear una categoria y mandarla en el handler
  bindFormProduD(handler) {

    document.getElementById('delPro').addEventListener("submit", function (event) {


      $("#delPro").addClass('was-validated');

      if (this.checkValidity() === false) {
        event.preventDefault();
        event.stopPropagation();
      } else {
        let list = [];

        const pro = document.getElementById("pro3");
        const pros = pro.selectedOptions;
        for (let i = 0; i < pros.length; i++) {
          list.push(pros[i].value);

        }

        handler(list)
      }

    });

  }

  //Bind para recibir los datos del formulario de la categoria
  //crear una categoria y mandarla en el handler
  bindFormPersonD(handler) {


    document.getElementById('delPer').addEventListener("submit", function (event) {

      let list = [];

      const act = document.getElementById("act3");
      const acts = act.selectedOptions;
      for (let i = 0; i < acts.length; i++) {
        list.push(acts[i].value);

      }


      let lista = [];

      const dir = document.getElementById("dir3");
      const dirs = dir.selectedOptions;
      for (let i = 0; i < dirs.length; i++) {
        lista.push(dirs[i].value);

      }

      handler(list, lista)
    });

  }




  //Bind para recibir los datos del formulario de la categoria
  //crear una categoria y mandarla en el handler
  bindFormCategory(handler) {

    document.getElementById('formCat').addEventListener("submit", function (event) {


      $("#formCat").addClass('was-validated');

      if (this.checkValidity() === false) {
        event.preventDefault();
        event.stopPropagation();
      } else {
        let img = document.getElementById('img').value;

        let aux = img.substring(12);

        let img_path = aux;

        let cate = new Category(document.getElementById('name').value, document.getElementById('des').value, img_path)

        handler(cate)
      }


    });

  }



  //Bind para recibir los datos del formulario de la categoria
  //crear una categoria y mandarla en el handler
  bindAssignActor(handler) {

    document.getElementById('asiAct').addEventListener("submit", function (event) {

      $("#asiAct").addClass('was-validated');

      if (this.checkValidity() === false) {
        event.preventDefault();
        event.stopPropagation();
      } else {
        let list = [];

        const act = document.getElementById("act4");
        const acts = act.selectedOptions;
        for (let i = 0; i < acts.length; i++) {
          list.push(acts[i].value);

        }


        let lista = [];

        const pro = document.getElementById("pro4");
        const pros = pro.selectedOptions;
        for (let i = 0; i < pros.length; i++) {
          lista.push(pros[i].value);

        }

        handler(list, lista)
      }



    });

  }


  //Bind para recibir los datos del formulario de la categoria
  //crear una categoria y mandarla en el handler
  bindDeassignActor(handler) {

    const selectOption = document.getElementById('pro');
    selectOption.addEventListener('change', function () {
      const selectedValue = selectOption.value;

      handler(selectedValue);

    });

  }

  //Bind para recibir los datos del formulario de la categoria
  //crear una categoria y mandarla en el handler
  bindDeassignActor2(handler) {

    document.getElementById('dasiAct').addEventListener("submit", function (event) {


      $("#dasiAct").addClass('was-validated');

      if (this.checkValidity() === false) {
        event.preventDefault();
        event.stopPropagation();
      } else {
        let actores = [];
        const selectOption = document.getElementById('pro2');
        const opcionesSeleccionadasActor = selectOption.selectedOptions;
        for (let i = 0; i < opcionesSeleccionadasActor.length; i++) {
          actores.push(opcionesSeleccionadasActor[i].value);

        }

        let pro = document.getElementById('pro');

        let production = pro.value;

        handler(actores, production);
      }



    });

  }


  //Bind para recibir los datos del formulario de la categoria
  //crear una categoria y mandarla en el handler
  bindDeassignDirector2(handler) {

    document.getElementById('dasiDir').addEventListener("submit", function (event) {


      $("#dasiDir").addClass('was-validated');

      if (this.checkValidity() === false) {
        event.preventDefault();
        event.stopPropagation();
      } else {
        let actores = [];
        const selectOption = document.getElementById('dir2');
        const opcionesSeleccionadasActor = selectOption.selectedOptions;
        for (let i = 0; i < opcionesSeleccionadasActor.length; i++) {
          actores.push(opcionesSeleccionadasActor[i].value);

        }

        let pro = document.getElementById('prot');

        let production = pro.value;

        handler(actores, production);
      }



    });

  }



  //Bind para recibir los datos del formulario de la categoria
  //crear una categoria y mandarla en el handler
  bindAssignDirector(handler) {

    document.getElementById('asiDir').addEventListener("submit", function (event) {

      $("#asiDir").addClass('was-validated');

      if (this.checkValidity() === false) {
        event.preventDefault();
        event.stopPropagation();
      } else {
        let list = [];

        const dir = document.getElementById("dir4");
        const dirs = dir.selectedOptions;
        for (let i = 0; i < dirs.length; i++) {
          list.push(dirs[i].value);

        }


        let lista = [];

        const pro = document.getElementById("pro4");
        const pros = pro.selectedOptions;
        for (let i = 0; i < pros.length; i++) {
          lista.push(pros[i].value);

        }

        handler(list, lista)
      }

    });

  }


  //Bind para recibir los datos del formulario de la categoria
  //crear una categoria y mandarla en el handler
  bindDeassignDirector(handler) {

    const selectOption = document.getElementById('prot');
    selectOption.addEventListener('change', function () {
      const selectedValue = selectOption.value;

      handler(selectedValue);

    });
  }


  //Bind para recibir los datos del formulario de la categoria
  //crear una categoria y mandarla en el handler
  bindFormPerson(handler) {

    document.getElementById('formPer').addEventListener("submit", function (event) {

      $("#formPer").addClass('was-validated');

      if (this.checkValidity() === false) {
        event.preventDefault();
        event.stopPropagation();
      } else {

        let name = document.getElementById('name').value;

        let last1 = document.getElementById('last1').value;

        let last2 = document.getElementById('last2').value;

        let year = document.getElementById('year').value;

        let img = document.getElementById('img').value;

        let aux = img.substring(12);

        let img_path = aux;

        let list = [];

        const rol = document.getElementById("rol");
        const rols = rol.selectedOptions;
        for (let i = 0; i < rols.length; i++) {
          list.push(rols[i].value);

        }

        let person = new Person(name, last1, last2, year, img_path);

        let rolPer = "";

        if (list.includes("Actor") && list.includes("Director")) {
          rolPer = "Both";
        } else if (list.includes("Actor")) {
          rolPer = "Act";

        } else if (list.includes("Director")) {
          rolPer = "Dir";

        }


        handler(person, rolPer)
      }

    });

  }



  //Bind para recibir los datos del formulario de la categoria
  //crear una categoria y mandarla en el handler
  bindFormProdu(handler) {

    document.getElementById('formPro').addEventListener("submit", function (event) {

      $("#formPro").addClass('was-validated');

      if (this.checkValidity() === false) {
        event.preventDefault();
        event.stopPropagation();
      } else {



        let title = document.getElementById('title').value;

        let nacion = document.getElementById('nacion').value;

        let year = document.getElementById('year').value;

        let img = document.getElementById('img').value;

        let aux = img.substring(12);

        let img_path = aux;

        let syn = document.getElementById('syn').value;

        let list = [];

        const act = document.getElementById("act2");
        const actors = act.selectedOptions;
        for (let i = 0; i < actors.length; i++) {
          list.push(actors[i].value);

        }

        const miSelect = document.getElementById("dir2");
        const valorSeleccionado = miSelect.value;

        let lista = [];

        const cat = document.getElementById("cat2");
        const categ = cat.selectedOptions;
        for (let i = 0; i < categ.length; i++) {
          lista.push(categ[i].value);

        }


        let seasons = document.getElementById('season');

        //En caso de que seasons no sea null, significa que hemos elegido una serie
        //si no será una película
        if (seasons) {

          let season = document.getElementById('season').value;

          let locX = document.getElementById('locX').value;

          let locY = document.getElementById('locY').value;

          let resources = document.getElementById('resources').value;


          let serie = new Serie(title, nacion, year, syn, img_path, [resources], [locX, locY], season);

          handler(serie, list, valorSeleccionado, lista)


        } else {
          let locX = document.getElementById('locX').value;

          let locY = document.getElementById('locY').value;

          let dur = document.getElementById('dur').value;

          let link = document.getElementById('link').value;

          let resource = new Resource(dur, link)

          let movie = new Movie(title, nacion, year, syn, img_path, [locX, locY], resource);

          handler(movie, list, valorSeleccionado, lista)
        }

      }

    });

  }



  showRemoveForm(type, actors, directors, productions) {
    this.main.empty();

    let div;


    if (type == "Produ") {

      this.main.append(`<div class="container">
        <h2>Eliminar producción</h2>
      <div class="row">
      <form id="delPro" novalidate>

        <div class="col-md-6">
          <div class="form-group">
          <label for='pro3'>Producciones a borrar</label>
          <select id='pro3' class="form-select custom-select" multiple aria-label="multiple select example" required>
          
          </select>
          <div class="invalid-feedback text-warning ">Debes escoger al menos una producción!</div>
          <div class="valid-feedback ">Correcto</div>

         
</div>
</div>

<div class="col-md-6 mt-3">
<button type="submit" id='deletePro' class="btn btn-danger">Eliminar</button>
</div>

</form>

</div>
</div>`)


      for (const pro of productions) {

        $('#pro3').append(`<option value="${pro.title}">${pro.title}</option>`)

      }



    } else if (type == "Per") {
      this.main.append(`<div class="container">
        <h2>Eliminar actor/es, director/es</h2>
      
      <form id="delPer">
      <div class="row">
      <div class="col-md-2">

      </div>
        <div class="col-md-5">
        <label for='act3'>Actores:</label>
          <select id='act3' class="form-select-sm" multiple aria-label="multiple select example">
          </select>
          </div>
          <div class="col-md-5">
          <label for='dir3'>Directores:</label>
          <select id='dir3' class="form-select-sm" multiple aria-label="multiple select example">
          </select>
          </div>

          </div>

          <div class="d-flex justify-content-center mt-4">
      <button type="submit" id='deletePer' class="btn btn-danger">Eliminar</button>
      </div>
      </form>
      
      </div>`);


      for (const per of actors) {
        let pers = `<option value="${per.actor.name} ${per.actor.lastname1}">${per.actor.name} ${per.actor.lastname1}</option>`;


        $('#act3').append(pers)

      }


      for (const dir of directors) {
        let dirs = `<option value="${dir.director.name} ${dir.director.lastname1}">${dir.director.name} ${dir.director.lastname1}</option>`;

        $('#dir3').append(dirs)

      }



    } else if (type == "Cat") {
      div = (`<div class="container">
      <h2>Eliminar categoria</h2>
    <div class="row">
    <form id="delCat" novalidate>

      <div class="col-md-6">
        
        <label for="cat" class="form-label">Nombre de la categoria:</label>
        <input type="text" class="form-control-md" id="cat" placeholder="Nombre" required pattern="[A-Z,a-z]{2-30}">
        <div class="invalid-feedback text-warning ">El nombre de la categoria es obligatorio!!</div>
        <div class="valid-feedback ">Correcto</div>
</div>

<div class="col-md-6">
<button type="submit" id='deleteCat' class="btn btn-danger">Eliminar</button>
</div>
</div>


</form>
</div >

        `)


    }

    this.main.append(div);

  }



  showAssignForm(type, actors, directors, productions) {
    this.main.empty();


    if (type == "Act") {

      this.main.append(`<div class="container">
      <h2>Asignar actor/es</h2>
    
    <form id="asiAct" novalidate>
    <div class="row">
    <div class="col-md-2">

    </div>
      <div class="col-md-5">
      <label for='act4'>Actores:</label>
        <select id='act4' class="form-select-sm" multiple aria-label="multiple select example" required>
        </select>
        <div class="invalid-feedback text-warning ">Este campo no puede estar vacio!</div>
        <div class="valid-feedback ">Correcto</div>
        </div>
        <div class="col-md-5">
        <label for='pro4'>Producciones:</label>
        <select id='pro4' class="form-select-sm" multiple aria-label="multiple select example" required>
        </select>
        <div class="invalid-feedback text-warning ">Este campo no puede estar vacio!</div>
        <div class="valid-feedback ">Correcto</div>
        </div>

        </div>

        <div class="d-flex justify-content-center mt-4">
    <button type="submit" id='assignPer' class="btn btn-warning">Asignar</button>
    </div>
    </form>
    
    </div>`);


      for (const per of actors) {
        let pers = `<option value="${per.actor.name} ${per.actor.lastname1}">${per.actor.name} ${per.actor.lastname1}</option>`;


        $('#act4').append(pers)

      }


      for (const pro of productions) {
        let dirs = `<option value="${pro.title}">${pro.title} </option>`;

        $('#pro4').append(dirs)

      }




    } else if (type == "Dir") {
      this.main.append(`<div class="container">
      <h2>Asignar director/es</h2>
    
    <form id="asiDir" novalidate>
    <div class="row">
    <div class="col-md-2">

    </div>
      <div class="col-md-5">
      <label for='act4'>Directores:</label>
        <select id='dir4' class="form-select-sm" multiple aria-label="multiple select example" required>
        </select>
        <div class="invalid-feedback text-warning ">Este campo no puede estar vacio!</div>
        <div class="valid-feedback ">Correcto</div>

        </div>
        <div class="col-md-5">
        <label for='pro4'>Producciones:</label>
        <select id='pro4' class="form-select-sm" multiple aria-label="multiple select example" required>
        </select>
        <div class="invalid-feedback text-warning ">Este campo no puede estar vacio!</div>
        <div class="valid-feedback ">Correcto</div>

        </div>

        </div>

        <div class="d-flex justify-content-center mt-4">
    <button type="submit" id='assignPer' class="btn btn-warning">Asignar</button>
    </div>
    </form>
    
    </div>`);


      for (const per of directors) {
        let pers = `<option value="${per.director.name} ${per.director.lastname1}">${per.director.name} ${per.director.lastname1}</option>`;


        $('#dir4').append(pers)

      }


      for (const pro of productions) {
        let dirs = `<option value="${pro.title}">${pro.title} </option>`;

        $('#pro4').append(dirs)

      }



    }

  }




  showDeassignForm(type, productions) {
    this.main.empty();


    if (type == "Act") {

      this.main.append(`
      <div class="container">

        <h2>Deasignar actor/es</h2>
    
        <form id="dasiAct" novalidate>
          <div class="row">

            <div class="col-md-5">
              <div class="form-group">
                <label for="pro">Selecciona producción:</label>
                <select class="form-select-sm" id="pro" required>
                <option value=""></option>
                
                </select> 
                <div class="invalid-feedback text-warning ">Este campo no puede estar vacio!</div>
                <div class="valid-feedback ">Correcto</div>
              </div>
            </div> 


            <div class="col-md-5">
            <div class="form-group" id='actores'>

            </div>
          </div> 
            
            
          </div>    
  
                <div class="d-flex justify-content-center mt-4">
                  <button type="submit" id='deassignPer' class="btn btn-warning">Deasignar</button>
                </div>
        </form>
      </div>`);

      for (const pro of productions) {
        let dirs = `<option value="${pro.title}">${pro.title} </option>`;

        $('#pro').append(dirs)


      }

    } else if (type == "Dir") {
      this.main.append(`
      <div class="container">

        <h2>Deasignar director/es</h2>
    
        <form id="dasiDir" novalidate>
          <div class="row">

            <div class="col-md-5">
              <div class="form-group">
                <label for="prot">Selecciona producción:</label>
                <select class="form-select-sm" id="prot" required>
                <option value=""></option>
                
                </select> 
                <div class="invalid-feedback text-warning ">Este campo no puede estar vacio!</div>
                <div class="valid-feedback ">Correcto</div>
              </div>
            </div> 


            <div class="col-md-5">
            <div class="form-group" id='directores'>

            </div>
          </div> 
            
            
          </div>    
  
                <div class="d-flex justify-content-center mt-4">
                  <button type="submit" id='deassignPer' class="btn btn-warning">Deasignar</button>
                </div>
        </form>
      </div>`);

      for (const pro of productions) {
        let dirs = `<option value="${pro.title}">${pro.title} </option>`;

        $('#prot').append(dirs)


      }
    }
  }


  showDeassignForm2(persons) {

    $('#actores').empty();
    $('#actores').append(`
    <label for="pro2">Selecciona actor/es:</label>
    <select class="form-select-sm" id="pro2" multiple required>
    <option value=""></option>
    
    </select> 
    <div class="invalid-feedback text-warning ">Este campo no puede estar vacio!</div>
    <div class="valid-feedback ">Correcto</div>
    <div class="invalid-feedback text-warning ">Este campo no puede estar vacio!</div>
    <div class="valid-feedback ">Correcto</div>
    `)

    for (const elem of persons) {
      let dirs = `<option value="${elem.name} ${elem.lastname1}">${elem.name} ${elem.lastname1}</option>`;

      $('#pro2').append(dirs)

    }

  }


  showDeassignFormD(persons) {

    $('#directores').empty();
    $('#directores').append(`
    <label for="dir2">Selecciona director/es:</label>
    <select class="form-select-sm" id="dir2" multiple required>
    <option value=""></option>
    
    </select> 
    <div class="invalid-feedback text-warning ">Este campo no puede estar vacio!</div>
    <div class="valid-feedback ">Correcto</div>
    `)

    for (const elem of persons) {
      let dirs = `<option value="${elem.name} ${elem.lastname1}">${elem.name} ${elem.lastname1}</option>`;

      $('#dir2').append(dirs)

    }

  }

  //Función que nos muestra una producción y sus caracteristicas de forma individual
  showSingleMovie(movie, directors, actors) {
    this.main.empty();

    let div2 = "";
    let div = "";

    let container = $("<div id='movie' class='container my-2'><div id='gap' class='row row-cols-md-2'> </div>");

    //Comprobamos si la producción es una pelicula o una serie,
    //para que dependiendo de lo que sea mostramos unos datos u otros
    if ((movie instanceof Movie)) {
      div = (`
        
      <div class="card bg-dark text-white col-sm-6 mx-auto">
      <img class="card-img" src="./img/1${movie.image}" alt="Card image">
      <div class="card-img-overlay">
      <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="currentColor" class="bi bi-play-circle" viewBox="0 0 16 16" preserveAspectRatio="xMidYMid meet">
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
      <path d="M6.271 5.055a.5.5 0 0 1 .52.038l3.5 2.5a.5.5 0 0 1 0 .814l-3.5 2.5A.5.5 0 0 1 6 10.5v-5a.5.5 0 0 1 .271-.445z"/>
    </svg>
      </div>
    </div>
  
    <div id="carta" class="card col-sm-2 mx-auto" style="width: 500px; height: 450px">
    <div class="body">
    <div class="card-body">
      <h5 class="card-title text-white">${movie.title} - ${movie.publication} - ${movie.nationality}</h5>

      <h6 class="card-subtitle mb-2 text-white">${movie.synopsis}</h6>
      <h6 class="card-subtitle mb-2 text-white">${movie.resource} </h6>
    <br>
      <h6 class="card-subtitle mb-2 text-white"> ${movie.locations} </h6>

     
      
  <br>
  <div class="separar">
      <p class="card-text text-white">Director</p>
      </div>
      
      <div id="dirs">

      </div>
      
      
      <br>
      <div class="separar">
      <p class="card-text text-white">Actors</p>
      </div>
      <div id="acts">

      </div>
        `);





    } else if (movie instanceof Serie) {
      div = (`
      <div class="row">
      <div class="card bg-dark text-white col-sm-6 mx-auto">
      <img class="card-img" src="./img/1${movie.image}" alt="Card image">
      <div class="card-img-overlay">
      <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="currentColor" class="bi bi-play-circle" viewBox="0 0 16 16" preserveAspectRatio="xMidYMid meet">
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
      <path d="M6.271 5.055a.5.5 0 0 1 .52.038l3.5 2.5a.5.5 0 0 1 0 .814l-3.5 2.5A.5.5 0 0 1 6 10.5v-5a.5.5 0 0 1 .271-.445z"/>
    </svg>
      </div>
    </div>
  
    <div id="carta" class="card col-sm-2 mx-auto" style="width: 500px; height: 450px">
    <div class="body">
    <div class="card-body">
      <h5 class="card-title text-white">${movie.title} - ${movie.publication} - ${movie.nationality}</h5>

      <h6 class="card-subtitle mb-2 text-white">${movie.synopsis}</h6>
      <h6 class="card-subtitle mb-2 text-white">Temporadas: ${movie.seasons}</h6>
      <br>
      <h6 class="card-subtitle mb-2 text-white">${movie.locations}</h6>

      <a href='#' id='single' data-serial='${movie.title}' class='btn btn-primary float prueba'> Ver </a>
  <br>

      <div class="separar">
      <p class="card-text text-white">Director</p>
      </div>

      <div id="dirs">
      
      </div>
      <br>
      <br>
      <div class="separar">
      <p class="card-text text-white">Actors</p>
      </div>
      <div id="acts">

      </div>
        `);

    }

    //Con el array que pasamos de actores, ahora los mostramos todos con sus links para
    //ir a su carta individual




    div = div + (`
    <a href='#' id='single' data-serial='${movie.title}' class='btn btn-primary float prueba'> Ver </a>

    <a href='#' id='ventana' data-serial='${movie.title}' class='btn btn-primary float prueba'> Abrir en otra ventana </a>
    </div>
    </div>
   </div>
  `)

    container.append(div)
    container.prepend(`<h1 class='titulo'>${movie.title}</h1>`);
    this.main.append(container);

    if (actors.length === 0) {
      $('#acts').append(`<p>Todavia no hay actores asignados</p>`);
    } else {
      for (let i = 0; i < actors.length; i++) {

        $('#acts').append(`
         
         <a href="#" id="a" class="card-link" data-serial="${actors[i].name} ${actors[i].lastname1}">${actors[i].name} ${actors[i].lastname1} ${actors[i].lastname2}</a>`);
      }
    }



    if (directors.length === 0) {
      $('#dirs').append(`<p>Todavia no hay directores asignados</p>`);
    } else {
      for (let i = 0; i < directors.length; i++) {

        $('#dirs').append(`
         
        <a href="#" id="d" class="card-link" data-serial="${directors[i].name} ${directors[i].lastname1}">${directors[i].name} ${directors[i].lastname1} ${directors[i].lastname2}</a>
   `);

      }
    }



  }

  //Función que muestra el botón de cerrar todas las ventanas en el navbar
  showCloseWindows() {
    let li = $(`<li class="nav-item dropdown">
    <a class="nav-link  text-white" href="#" id="navClose" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      Cerrar todas las ventanas
    </a>
  </li>`);


    this.navbar.append(li);
  }


  //Función para mostrar la carta individual de un director
  //con su nombre y apellidos, fecha de nacimiento y las producciones en las que ha participado
  showSingleDirector(dir, ms) {
    this.main.empty();

    //   let div2 = "";

    this.main.append(`
   <div id="sng">
   <div class="row">
    <div class="col-md-2 mx-auto" >
      <div class="card">
        <img src="./img/${dir.director.picture}" class="card-img-top" alt="...">
        <div class="card-body sin">
          <h5 class="card-title text-dark">${dir.director.name} ${dir.director.lastname1} ${dir.director.lastname2}</h5>
          <p class="card-text text-dark">${dir.director.born}</p>
          <a class="card-text text-dark"></p>

                    <div id="ms">
                   
                   </div>
                   </div>
                   </div>
                   </div>
                   </div>
  
          `);



    //   //Aqui recorremos las producciones con un bucle porque no sabemos
    //   //en cuantas producciones ha participado
    for (let i = 0; i < ms.length; i++) {
      $('#ms').append(`<a href="#" class="card-link" data-serial="${ms[i].title}">${ms[i].title} ${ms[i].publication} </a>`);

    }
  }

  //Función para mostrar la carta de un actor individualmente
  // donde veremos su nombre y apellidos, fecha de nacimiento y producciones en las que ha participado
  showSingleActor(act, ms) {
    this.main.empty();

    let div2 = "";

    let div = (`
    <div id="sng">
    <div class="row">
     <div class="col-md-2 mx-auto">
       <div class="card">
         <img src="./img/${act.actor.picture}" class="card-img-top" alt="...">
         <div class="card-body sin">
           <h5 class="card-title text-dark">${act.actor.name} ${act.actor.lastname1} ${act.actor.lastname2}</h5>

           <p class="card-text text-dark"> ${act.actor.born}</p>
  `);

    //Aqui recorremos las producciones con un bucle porque no sabemos
    //en cuantas producciones ha participado
    for (let i = 0; i < ms.length; i++) {

      div2 = div2 +
        (`
            <div id="ms">
           <a href="#" class="card-link" data-serial="${ms[i].title}">${ms[i].title} ${ms[i].publication} </a>

      `);

    }

    div = div + div2 + (`          </div>
    </div>
   </div>
   </div>
   </div>`);

    this.main.append(div);

  }

  // //Bind para mostrar una pelicula individual
  bindSingleMovie(handler) {
    $('#product-list').find('a.btn').click((event) => {
      let serial = $(event.target).closest($('a')).get(0).dataset.serial;
      this.#executeHandler(
        handler, [serial],
        'main',
        { action: 'showSingle', serial: serial },
        '#movie', event
      );
    });
  }




  //Bind para mostrar un director individual desde una pelicula
  bindDirectorMovie(handler) {
    let manejador = this.#executeHandler;
    $('#dirs').find('a').click(function (event) {
      let serial = $(event.target).closest($('a')).get(0).dataset.serial;
      manejador(
        handler, [serial],
        'main',
        { action: 'showDirector', serial: serial },
        '#movie', event
      );
    });
  }


  //Bind para mostrar un director individual desde una pelicula
  bindActorMovie(handler) {
    let manejador = this.#executeHandler
    $('#acts').find('a').click(function (event) {
      let serial = $(event.target).closest($('a')).get(0).dataset.serial;
      manejador(
        handler, [serial],
        'main',
        { action: 'showActorM', serial: serial },
        '#act', event
      );

    })
  }

  //Bind para mostrar la produccion en la que ha participado esa persona
  bindMovieCast(handler) {
    let manejador = this.#executeHandler
    $('#ms').find('a').click(function (event) {
      let serial = $(event.target).closest($('a')).get(0).dataset.serial;
      manejador(
        handler, [serial],
        'main',
        { action: 'showMovieAD', serial: serial },
        '#act', event
      );
    })
  }


  //Bind que al pulsar en un botón que sale en cada pelicula individual, nos muestra
  //una ventana nueva con los datos de la pelicula
  bindNewWindow(handler) {
    $('#ventana').click((event) => {
      this.productWindow = window.open("production.html", event.target.dataset.serial, "width=800, height=600, top=250, left=250");
      this.productWindow.addEventListener('DOMContentLoaded', () => {
        handler(event.target.dataset.serial)
      });

    });
  }

  //Bind que cierra todas las ventanas al pulsar en el boton
  //de cerrar todas la ventanas
  bindCloseWindow(handler) {
    $('#navClose').click((event) => {
      handler()
    });

  }


  //Función que nos muetra las producciones que tiene una categoria, una por una
  showNewWindowProduction(movie) {
    let main = $(this.productWindow.document).find('main');

    this.productWindow.document.title = `${movie.title}`

    let div = "";


    main.empty();

    if (movie instanceof Movie) {

      //Mostramos la pelicula
      div = $(`
          
    <div class="card mb-3" style="max-width: 640px;">
<div class="row g-0">
<div class="col-md-4">
<img src="./img/${movie.image}" id='image' class="img-fluid rounded-start" alt="...">
</div>
<div class="col-md-8">
<div class="card-body">
  <h5 class="card-title">${movie.title}</h5>
  <p class="card-text">${movie.synopsis}</p>
  <p class="card-text">${movie.nationality} ${movie.resource}</p>
  <p class="card-text"><small class="text-muted">${movie.publication}</small></p>
</div>
</div>
</div>
</div>`)

    } else if (movie instanceof Serie) {
      div = $(`
          
      <div  id='card-w'  class="card mb-3" style="max-width: 640px;">
  <div  class="row g-2">
  <div   class="col-md-4">
  <img src="./img/${movie.image}" id='image' class="img-fluid rounded-start" alt="...">
  </div>
  <div class="col-md-8">
  <div class="card-body">
    <h5 class="card-title">${movie.title}</h5>
    <p class="card-text">${movie.synopsis}</p>
    <p class="card-text">${movie.nationality} Temporadas: ${movie.seasons}</p>
    <p class="card-text"><small class="text-muted">${movie.publication}</small></p>
  </div>
  </div>
  </div>
  </div>`)
    }
    ;

    main.append(div);

  }


}

export default VideoSystemView;
