import VideoSystem from './VideoSystemModel.js';
import VideoSystemController from './VideoSystemController.js';
import VideoSystemView from './VideoSystemView.js';

let VideoSystemApp;
$(function () {
	VideoSystemApp = new VideoSystemController(
		VideoSystem.getInstance(), new VideoSystemView()
	);

		
	const historyActs = {
		//Guardamos todos los eventos que se irán haciendo
		//y a la función que llaman
		init: () => {
			VideoSystemApp.handleInit();
		},
		showInit: (event) => VideoSystemApp.handleShowMovies(event.state.category),
		showSingle: (event) => VideoSystemApp.handleSingleMovie(event.state.serial),
		showCarPro: (event) => VideoSystemApp.handleSingleMovie(event.state.serial),
		showActor:(event) => VideoSystemApp.handleSingleActor(event.state.category),
		showDirector:(event) => VideoSystemApp.handleProductsDirectors(event.state.serial),
		showActorM:(event) => VideoSystemApp.handleSingleActor(event.state.serial),
		showMovieAD:(event) => VideoSystemApp.handleSingleMovie(event.state.serial),
		showDirectorNav:(event) => VideoSystemApp.handleProductsDirectors(event.state.category)
	}
	window.addEventListener('popstate', function (event) {
		if (event.state) {
			historyActs[event.state.action](event);
		}


	});

	history.replaceState({ action: 'init' }, null);

});

export default VideoSystemApp;
